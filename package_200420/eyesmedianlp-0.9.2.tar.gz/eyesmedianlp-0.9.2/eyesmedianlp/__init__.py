import os
from enum import Enum


def current_module_path():
    module_path = os.path.realpath(__file__)
    return os.path.dirname(module_path)


class LanguageType(Enum):
    zh_CN = "zh_CN"
    zh_TW = "zh_TW"
    en_US = "en_US"
