# -*- coding:utf-8 -*-
import logging
import numpy as np
from scipy import spatial

logger = logging.getLogger("eyesmedianlp")


def sentence_similarity(sent1_words, sent2_words, w2v_model):
    """
    計算兩個單詞之間的相似度，越接近1表示越相似(需過濾停止詞)
    reference: http://proceedings.mlr.press/v37/kusnerb15.pdf
    :param sentence1: sentence.split()
    :param sentence2: sentence.split()
    :param w2v_model: 預訓練的詞向量
    :return:
    """

    def avg_feature_vector(sent_words, w2v_model):
        # words = [term["word"] for term in self.eyes_tokenizer.standard_tokenizer(sentence, filter_stop_word=True)]  # sentence.split()
        words = list(set(sent_words))
        # logger.info("avg_feature_vector:{}".format(words))
        feature_vec = np.zeros((w2v_model.vector_size,), dtype='float32')
        n_words = 0
        for word in words:
            if word in w2v_model:
                n_words += 1
                feature_vec = np.add(feature_vec, w2v_model.wv.get_vector(word))
        if (n_words > 0):
            feature_vec = np.divide(feature_vec, n_words)
        return feature_vec

    s1_afv = avg_feature_vector(sent1_words, w2v_model)
    s2_afv = avg_feature_vector(sent2_words, w2v_model)
    if np.count_nonzero(s1_afv) == 0 or np.count_nonzero(s2_afv) == 0:
        return 0
    sim = 1 - spatial.distance.cosine(s1_afv, s2_afv)
    return sim
