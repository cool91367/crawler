# -*- coding:utf-8 -*-
from __future__ import division
from __future__ import print_function

import os
import glob
import logging

logger = logging.getLogger("eyesmedianlp")

__all__ = [
    "CUSTOM_DICT_PATH",
    "init_hanlp_env"
]

# jar root path
_JAR_PATH = os.path.dirname(os.path.realpath(__file__))
_CONFIG_FILE = os.path.join(_JAR_PATH, "hanlp.properties")
CUSTOM_DICT_PATH = "data"

jar_file = None
jar_version = None
dependency = []


def _get_jar_versions():
    # check path
    if not os.path.exists(_JAR_PATH):
        raise ValueError("not install hanlp in path:{}".format(_JAR_PATH))

    versions = []
    for jar in glob.glob(os.path.join(_JAR_PATH, "hanlp-*.jar")):
        versions.append(os.path.basename(jar)[len("hanlp-"):-len(".jar")])
    if not versions:
        raise ValueError("not found jar file in path:{}".format(_JAR_PATH))

    versions = sorted(versions, reverse=True)
    if versions:
        global jar_file, jar_version
        jar_version = versions[0]
        jar_file = os.path.join(_JAR_PATH, "hanlp-{}.jar".format(jar_version))

    logger.info("current installed jar is {}".format(jar_file))


def _set_dictionary_data_path(dict_root_path):
    # check dictionary path
    if not os.path.exists(dict_root_path):
        raise ValueError("dictionary root path not found, input root path is {}".format(dict_root_path))

    global CUSTOM_DICT_PATH
    CUSTOM_DICT_PATH = os.path.join(dict_root_path, CUSTOM_DICT_PATH)
    if not os.path.exists(CUSTOM_DICT_PATH) or not os.path.isdir(CUSTOM_DICT_PATH):
        raise ValueError("dictionary file not found in path:{}".format(CUSTOM_DICT_PATH))

    # check properties file
    if not os.path.isfile(_CONFIG_FILE):
        raise ValueError("not found {}".format(_CONFIG_FILE))

    # replace config
    content = []
    with open(_CONFIG_FILE, encoding="utf-8") as f:
        for line in f:
            if line.startswith("root"):
                line = "root={}{}".format(dict_root_path, os.linesep)
            content.append(line)
    with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
        f.writelines(content)

    logger.info("setting dictionary data path is {}".format(CUSTOM_DICT_PATH))


def init_hanlp_env(dict_file_path):
    _get_jar_versions()
    _set_dictionary_data_path(dict_file_path)

    global dependency
    dependency.append(jar_file)
    dependency.append(_JAR_PATH)
    return os.pathsep.join(dependency)

    # HANLP_JVM_XMS = "1g"
    # HANLP_JVM_XMX = "1g"
    #
    # pathsep = os.pathsep
    # JAVA_JAR_CLASSPATH = "-Djava.class.path=%s%s%s" % (HANLP_JAR_FILE, pathsep, HANLP_PATH)
    # print("JAVA_JAR_CLASSPATH: [%s]" % JAVA_JAR_CLASSPATH)
    #
    # # 啓動JVM
    # startJVM(
    #     getDefaultJVMPath(),
    #     JAVA_JAR_CLASSPATH,
    #     "-Xms%s" % HANLP_JVM_XMS,
    #     "-Xmx%s" % HANLP_JVM_XMX)

# init_hanlp_env()
