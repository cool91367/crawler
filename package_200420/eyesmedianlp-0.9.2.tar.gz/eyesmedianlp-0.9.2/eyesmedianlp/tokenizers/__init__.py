# -*- coding:utf-8 -*-
from __future__ import division
from __future__ import print_function

import logging
import jpype
from jpype import startJVM, getDefaultJVMPath, JClass, isThreadAttachedToJVM, attachThreadToJVM, isJVMStarted

logger = logging.getLogger("eyesmedianlp")


def start_jvm(java_class_path, jvm_xms="1g", jvm_xmx="2g"):
    if not java_class_path:
        logger.error("java_class_path is empty, start JVM failure...")
        return

    if isJVMStarted():
        logger.info("JVM is started...")
        return

    javaClassPath = "-Djava.class.path={}".format(java_class_path)
    jvmXms = "-Xms{}".format(jvm_xms)
    jvmXmx = "-Xmx{}".format(jvm_xmx)
    try:
        logger.info("use JVM(jpype:{}), jvmXms:{}, jvmXmx:{}, javaClassPath:{}".format(jpype.__version__, jvmXms, jvmXmx, javaClassPath))
        startJVM(getDefaultJVMPath(), javaClassPath, jvmXms, jvmXmx, convertStrings=True)
        logger.info("JVM is starting....")
    except:
        logger.error("start JVM failure, jvmXms:{}, jvmXmx:{}, javaClassPath:{}".format(jvmXms, jvmXmx, javaClassPath))
        raise


def attach_jvm_to_thread():
    """
    use attachThreadToJVM to fix multi-thread issues: https://github.com/hankcs/pyhanlp/issues/7
    """
    if not isThreadAttachedToJVM():
        attachThreadToJVM()


class SafeJClass(object):
    def __init__(self, proxy):
        """
        JClass的線程安全版
        :param proxy: Java類的完整路徑，或者一個Java對象
        """
        attach_jvm_to_thread()
        self._proxy = JClass(proxy) if type(proxy) is str else proxy

    def __getattr__(self, attr):
        attach_jvm_to_thread()
        return getattr(self._proxy, attr)

    def __call__(self, *args):
        if args:
            proxy = self._proxy(*args)
        else:
            proxy = self._proxy()
        return SafeJClass(proxy)


class LazyLoadingJClass(object):
    def __init__(self, proxy):
        """
        惰性加載Class。僅在實際發生調用時才觸發加載，適用於包含資源文件的靜態class
        :param proxy:
        """
        self._proxy = proxy

    def __getattr__(self, attr):
        attach_jvm_to_thread()
        self._lazy_load_jclass()
        return getattr(self._proxy, attr)

    def lazy_load_jclass(self):
        if type(self._proxy) is str:
            self._proxy = JClass(self._proxy)

    def __call__(self, *args):
        self._lazy_load_jclass()
        if args:
            proxy = self._proxy(*args)
        else:
            proxy = self._proxy()
        return SafeJClass(proxy)
