# -*- coding:utf-8 -*-
import os
import logging
import traceback
import re
import eyesmedianlp.tokenizers.hanlp as hanlp
import eyesmedianlp.tokenizers.ik as ik
from jpype import JClass
from eyesmedianlp.tokenizers import start_jvm, SafeJClass
from eyesmedianlp import LanguageType

logger = logging.getLogger("eyesmedianlp")

DEFULAT_TOKEN_LANGUAGE = LanguageType.zh_TW.value
DEFULAT_JVM_XMS = "1g"
DEFULAT_JVM_XMX = "2g"


class TokenProvider(object):
    DEFAULT_SYMBOL_DICT = "symbolwords.txt"
    __enable_multithreading = False

    def __init__(self, dict_root_path, language=DEFULAT_TOKEN_LANGUAGE, jvm_xms=DEFULAT_JVM_XMS, jvm_xmx=DEFULAT_JVM_XMX, num_threads=0):
        # 啓動JVM
        java_class_path = os.pathsep.join([
            hanlp.init_hanlp_env(dict_root_path),
            ik.init_ik_env(dict_root_path)
        ])
        start_jvm(java_class_path, jvm_xms=jvm_xms, jvm_xmx=jvm_xmx)

        self.language = language

        # loading java class:IKAnalyzeProvider
        self.IKAnalyzeProvider = SafeJClass("org.wltea.analyzer.IKAnalyzeProvider")

        # loading java class:HanLP
        self.HanLP = SafeJClass("com.hankcs.hanlp.HanLP")
        self.HanLPConfig = JClass("com.hankcs.hanlp.HanLP$Config")  # inner class
        self.StandardTokenizer = SafeJClass("com.hankcs.hanlp.tokenizer.StandardTokenizer")
        self.NLPTokenizer = SafeJClass("com.hankcs.hanlp.tokenizer.NLPTokenizer")
        self.IndexTokenizer = SafeJClass("com.hankcs.hanlp.tokenizer.IndexTokenizer")
        self.SpeedTokenizer = SafeJClass("com.hankcs.hanlp.tokenizer.SpeedTokenizer")
        self.TraditionalChineseTokenizer = SafeJClass("com.hankcs.hanlp.tokenizer.TraditionalChineseTokenizer")
        if num_threads > 0:
            self.TraditionalChineseTokenizer.enableMultithreading(num_threads)
            self.StandardTokenizer.enableMultithreading(num_threads)

        self.CoreStopWordDictionary = SafeJClass("com.hankcs.hanlp.dictionary.stopword.CoreStopWordDictionary")  # 停止詞詞典
        self.CustomDictionary = SafeJClass("com.hankcs.hanlp.dictionary.CustomDictionary")  # 用戶自定義詞典

        self.StandardTokenizer.SEGMENT.enableOffset(True)

        # 載入自訂字典檔
        self.custom_stop_words = []
        # self.add_stop_word_dictionary(os.path.join(dict_root_path, self.DEFAULT_SYMBOL_DICT))
        # self.add_custom_dict_from_path(ik.CUSTOM_DICT_PATH)

    def enable_debug(self):
        self.HanLPConfig.enableDebug(True)
        self.IKAnalyzeProvider.enableDebug(True)

    def add_custom_dict_from_path(self, file_path):
        """
        詞彙加載：不會清除緩存，即使詞會被刪除依然還是會存在
        如果有需要清除且重新載入，可使用reload_custom_dict_from_path
        :param file_path:
        :return:
        """
        if not os.path.exists(file_path) or not os.path.isdir(file_path):
            logger.warning("custom dictionary file not found...")
            return
        files = os.listdir(file_path)
        for file_name in files:
            self.add_custom_dict(os.path.join(file_path, file_name))

    def add_custom_dict(self, file):
        if os.path.isdir(file):
            return
        if not os.path.exists(file):
            logger.warning("custom dictionary file({}) not found...".format(file))
            return
        try:
            add_count = 0
            with open(file, encoding="utf-8") as stream:
                for line in stream.read().splitlines():
                    # self.CustomDictionary.add(line)
                    items = re.split(r"\t|\s", line)
                    if len(items) == 1:
                        # 沒包含詞性
                        self.CustomDictionary.add(line)
                    elif len(items) % 2 == 1:
                        # 包含詞性
                        self.CustomDictionary.add(items[0], " ".join(items[1:]))
                    # else:
                    #     logger.info("Please set custom dict in this form {word} {pos} {weight}")

                    add_count += 1
            logger.info("add custom dictionary success, file is {}, total is {}".format(file, add_count))
        except:
            logger.error("add custom dictionary failure, file is {}".format(file))
            # logger.error(traceback.format_exc())

    def reload_custom_dict_from_path(self, file_path):
        """
        詞彙熱加載：會清除緩存並重新載入
        :param file_path:
        :return:
        """
        if not os.path.exists(file_path):
            logger.warning("custom dictionary file not found...")
            return
        try:
            count = self.CustomDictionary.reloadExtDictByFilePath(file_path)
            logger.info("add custom dictionary success, path is {}, total is {}".format(file_path, count))
        except:
            logger.error("add custom dictionary failure, path is {}".format(file_path))
            # logger.error(traceback.format_exc())

    def add_stop_word_dictionary(self, file, reset=False):
        if os.path.isdir(file):
            return
        if not os.path.exists(file):
            logger.warning("custom dictionary file({}) not found...".format(file))
            return
        try:
            with open(file, encoding="utf-8") as stream:
                self.custom_stop_words += stream.read().splitlines()
            self.custom_stop_words = list(set(self.custom_stop_words))
            logger.info("add custom stop word success, file is {}, total is {}".format(file, len(self.custom_stop_words)))
        except:
            logger.error("add custom stop word failure, file is {}".format(file))
            # logger.error(traceback.format_exc())

    def smart_tokenizer(self, text, filter_stop_word=False):
        try:
            words = self.IKAnalyzeProvider.segmentSmart(text)
            if filter_stop_word:
                words = self.filter_stopwords(words)
            return words
        except:
            logger.error(traceback.format_exc())
            raise

    def max_word_tokenizer(self, text, filter_stop_word=False):
        try:
            words = self.IKAnalyzeProvider.segment(text)
            if filter_stop_word:
                words = self.filter_stopwords(words)
            return words
        except:
            logger.error(traceback.format_exc())
            raise

    def speed_tokenizer(self, text, seg_to_sentence=False, filter_stop_word=False):
        return self.__hanlp_tokenizer(self.SpeedTokenizer, text, seg_to_sentence, filter_stop_word)

    def standard_tokenizer(self, text, language=None, seg_to_sentence=False, filter_stop_word=False):
        if not language or language == DEFULAT_TOKEN_LANGUAGE or self.language == DEFULAT_TOKEN_LANGUAGE:
            return self.tw_tokenizer(text, seg_to_sentence=seg_to_sentence, filter_stop_word=filter_stop_word)
        return self.__hanlp_tokenizer(self.StandardTokenizer, text, seg_to_sentence, filter_stop_word)

    def nlp_tokenizer(self, text, seg_to_sentence=False, filter_stop_word=False):
        return self.__hanlp_tokenizer(self.NLPTokenizer, text, seg_to_sentence, filter_stop_word)

    def index_tokenizer(self, text, seg_to_sentence=False, filter_stop_word=False):
        return self.__hanlp_tokenizer(self.IndexTokenizer, text, seg_to_sentence, filter_stop_word)

    def tw_tokenizer(self, text, seg_to_sentence=False, filter_stop_word=False):
        return self.__hanlp_tokenizer(self.TraditionalChineseTokenizer, text, seg_to_sentence, filter_stop_word)

    def filter_space(self, text):
        text = re.compile("\s+").sub(" ", text)
        # en_txt = re.compile("\s{,1}[\w]+\s{,1}").findall(text)
        # regex = re.compile("\w*[A-Za-z]\s$")
        en_txt = re.compile("\s{,1}[\w]+\s{,1}|\W+").findall(text)
        regex = re.compile("\w*[A-Za-z]+\d*\s$")
        for idx, en in enumerate(en_txt):
            if regex.match(en):
                continue
            en_txt[idx] = re.compile("\s+").sub("", en)
        # logger.info(en_txt)
        en_txt = "".join(en_txt)
        return en_txt

    def filter_stopwords(self, term_list):
        if not self.custom_stop_words:
            return term_list
        result = []
        for term in term_list:
            word = term if isinstance(term, str) else term.word
            if word not in self.custom_stop_words:
                result.append(term)
        return result

    def __hanlp_tokenizer(self, tokenizer_obj, text, seg_to_sentence, filter_stop_word):
        try:
            text = self.filter_space(text)

            if seg_to_sentence:
                term_list = tokenizer_obj.seg2sentence(text)
            else:
                term_list = tokenizer_obj.segment(text)

            if filter_stop_word:
                self.CoreStopWordDictionary.apply(term_list)
                term_list = self.filter_stopwords(term_list)

            result = []
            for term in term_list:
                result.append({
                    "word": term.word,
                    "offset": term.offset,
                    "nature": str(term.nature)
                })
            return result
        except:
            logger.error(traceback.format_exc())
            raise

    def cn2tw(self, text):
        """
        簡轉繁
        :param text:繁體中文
        :return:簡體中文
        """
        try:
            return self.HanLP.s2tw(text)
        except:
            logger.error(traceback.format_exc())
        return text

    def tw2cn(self, text):
        """
        繁轉簡
        :param text:簡體中文
        :return:繁體中文
        """
        try:
            return self.HanLP.tw2s(text)
        except:
            logger.error(traceback.format_exc())
        return text

    def extract_words(self, document, size, new_words=False):
        try:
            word_info_list = self.HanLP.extractWords(document, size, new_words)
            result = []
            for word_info in word_info_list:
                result.append({
                    "left": word_info.left,
                    "right": word_info.right,
                    "text": word_info.text,
                    "frequency": word_info.frequency,
                    "p": word_info.p,
                    "leftEntropy": word_info.leftEntropy,
                    "rightEntropy": word_info.rightEntropy,
                    "aggregation": word_info.aggregation,
                    "entropy": word_info.entropy
                })
            return result
        except:
            logger.error(traceback.format_exc())
            raise

    def extract_keyword(self, content, size):
        """
        提取關鍵詞
        :param content:內容
        :param size:提取多少個關
        :return:關鍵詞列表
        """
        try:
            return self.HanLP.extractKeyword(content, size)
        except:
            logger.error(traceback.format_exc())
            raise

    def extract_phrase(self, text, size):
        """
        提取短語
        :param text:文本
        :param size:提取多少個
        :return:短語列表
        """
        try:
            return self.HanLP.extractPhrase(text, size)
        except:
            logger.error(traceback.format_exc())
            raise

    def extract_summary(self, content, size, sentence_separator=None):
        """
        自動摘要，內容的句子預設分割符為，,。:：「」？?！!；;
        :param content:內容
        :param size:摘要多少個
        :return:摘要列表
        """
        if not sentence_separator:
            sentence_separator = "[，,。:：“”？?！!；;]"
        try:
            return self.HanLP.extractSummary(content, size, sentence_separator)
        except:
            logger.error(traceback.format_exc())
            raise
