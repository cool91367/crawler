# -*- coding: utf-8 -*-

# Created by JoJo. 2019.7.23
# detect and correct close pronounced words, ex: 因該, 應該
# Be careful!
# 1. Don't add both two closely pronounced words into the dictionary. ex: 忘記, 旺季
# You should should the most correct one, let's say in most cases. So choose '忘記' in this case
# 2. It could not detect the context of word. ex: 我喜歡這座程式.
# 3. You should add all possible correct words into the dictionary. ex: 本州, 本週

# @算法簡介
# distance = 注音差距 + 錯字差距
# ex. 因該、應該
# 注音差距 = 1 (ㄥ, ㄣ)
# 字面差距 = 1 (因, 應)
# dis(因該, 應該) = 2
# 但我們額外給一個條件，如果是常見的錯誤，距離只會算0.5，例如(ㄔㄘ, ㄣㄥ)等

from pypinyin import pinyin, Style
import re
import os

MAX_EDIT_DISTANCE = 2
MIN_LENGTH_OF_ERROR = 2
MAX_LENGTH_OF_ERROR = 9
PACKAGE_PATH = os.path.dirname(os.path.realpath(__file__))
VOCAB_FILE = os.path.join(PACKAGE_PATH, "vocab.txt")


def load_base_vocab():
    with open(VOCAB_FILE, encoding="utf-8") as f:
        char_list = f.read().split('\n')
    return char_list


class PinyinSpace(object):
    def __init__(self):
        self.vector = [{}, {}, {}, {}, {},
                       {}, {}, {}, {}, {}]  # 最高支援到9個字
        self.bopomo_lookup = self.__build_bopomo_lookup()
        self.common_error = self.__build_common_error()

    def __build_bopomo_lookup(self):
        bopomo = ["UNK",
                  "ㄅ", "ㄆ", "ㄇ", "ㄈ", "ㄉ", "ㄊ", "ㄋ", "ㄌ", "ㄍ", "ㄎ", "ㄏ", "ㄐ", "ㄑ", "ㄒ", "ㄓ", "ㄔ", "ㄕ", "ㄖ",
                  "ㄗ", "ㄘ", "ㄙ", "ㄧ", "ㄨ", "ㄩ", "ㄚ", "ㄛ", "ㄜ", "ㄝ", "ㄞ", "ㄟ", "ㄠ", "ㄡ", "ㄢ", "ㄣ", "ㄤ", "ㄥ",
                  "ㄦ",
                  "ˊ", "ˇ", "ˋ", "˙"]
        bopomo_lookup = {}
        for idx, symbol in enumerate(bopomo):
            bopomo_lookup[symbol] = idx
        return bopomo_lookup

    def __build_common_error(self):
        # 常見的錯誤距離會更近
        err_list = [['ㄋ', 'ㄌ', 'ㄖ'], ['ㄓ', 'ㄗ'], ['ㄥ', 'ㄣ'], ['ㄔ', 'ㄘ']]
        common_error = []
        for err in err_list:
            err_idx = []
            for symbol in err:
                err_idx.append(self.bopomo_lookup[symbol])
            common_error.append(err_idx)
        return common_error

    def levenshtein_distance(self, a, b):
        assert len(a) == len(b)
        _len = len(a)
        dis = 0
        for idx in range(0, _len, 4):
            for chunk in range(idx, idx + 4):
                if a[chunk] != b[chunk]:
                    flag = False
                    for err in self.common_error:
                        if a[chunk] in err and b[chunk] in err:
                            dis += 0.5
                            flag = True
                            break
                    if not flag:
                        dis += 1
        return dis

    def pinyin2vec(self, vocab):
        vocab = pinyin(vocab, style=Style.BOPOMOFO)
        vec = []
        for char in vocab:
            sm_vec = []
            for pin in char[0]:
                index = self.bopomo_lookup[pin]
                sm_vec.append(index)
            while len(sm_vec) != 4:
                sm_vec.append(0)
            vec.extend(sm_vec)
        return vec

    def add_vocab(self, vocab_list):
        for vocab in vocab_list:
            vocab_len = len(vocab)
            idx_vec = self.pinyin2vec(vocab)
            self.vector[vocab_len][vocab] = idx_vec

    def exist(self, vocab):
        vocab_len = len(vocab)
        if vocab in self.vector[vocab_len]:
            return True
        else:
            return False

    def word_edit_distance(self, a, b):
        assert len(a) == len(b)
        dis = 0
        for idx in range(len(a)):
            if a[idx] != b[idx]:
                dis += 1
        return dis

    def similar(self, vocab):
        vocab_len = len(vocab)
        vec = self.pinyin2vec(vocab)
        cand_bag = []
        for cand, cand_vec in self.vector[vocab_len].items():
            distance = self.levenshtein_distance(vec, cand_vec)
            distance += self.word_edit_distance(cand, vocab)
            if distance <= 2:
                cand_bag.append((cand, distance))
        return cand_bag


class Corrector(object):
    def __init__(self):
        self.pinyin_space = PinyinSpace()
        self.chinese = re.compile(r'[^\u4e00-\u9fff]+')
        self.common_pair_dict = None
        self.context_pair_dict = None
        self.add_vocab(load_base_vocab())

    def add_vocab(self, vocab_list):
        try:
            self.pinyin_space.add_vocab(vocab_list)
        except:
            raise TypeError("Fail to add vocab_list: {}".format(vocab_list))

    def check(self, sentence, dim=4):
        # @params
        # sentence ==> str
        # dim ==> int, you can view it as window size
        # @return
        # error_bag ==> list of tuples
        # [(origin, (correct word, distance))]
        sentence = re.sub(self.chinese, ' ', sentence)
        sentence = re.sub(r'^\s', '', sentence)
        sentence = re.sub(r'\s$', '', sentence)

        sentence_list = sentence.split(' ')
        if dim > MAX_LENGTH_OF_ERROR or dim <= 0:
            raise ValueError("dim should be between {}~{} and could not be larger than sentence size: {}".format(
                MIN_LENGTH_OF_ERROR, MAX_LENGTH_OF_ERROR, len(sentence)))
        error_bag = []
        for sentence in sentence_list:
            for idx in range(MIN_LENGTH_OF_ERROR, dim + 1):
                for offset in range(len(sentence) - idx + 1):
                    word = sentence[offset: offset + idx]
                    # The word already exists in dictionary, means no errors
                    if not self.pinyin_space.exist(word):
                        cand = self.pinyin_space.similar(word)
                        if cand:
                            cand = sorted(cand, key=lambda k: k[1], reverse=True)
                            error_bag.append((word, cand[0]))
        return error_bag

    # todo
    def add_common_pair(self, common_pair):
        # 增加常見的錯別組合，有對到的話直接回傳
        # ('{wrong}', '{correct}')
        wrong_word, correct_word = common_pair
        if wrong_word in self.common_pair_dict:
            self.common_pair_dict[wrong_word].append(common_pair)
        else:
            self.common_pair_dict[wrong_word] = [common_pair]
