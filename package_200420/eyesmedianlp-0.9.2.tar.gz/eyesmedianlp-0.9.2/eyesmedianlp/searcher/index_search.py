# -*- coding: utf-8 -*-

# Created by JoJo. 2019.7.31

# @用法
# 請搭配 pos_filter
# pos_filter = StandardPOSFilter(tokenizer)
# idx_searcher = IndexSearch(pos_filter)
# idx_searcher.put_idx_data(data) # "Q"
# idx_searcher.predict(txt)

# @注意事項
# 分詞結果大大影響此方法效能，請務必加載所有領域熱詞

import time
import logging
from sys import getsizeof

logger = logging.getLogger("eyesmedianlp")


class IndexSearch(object):
    def __init__(self, pos_filter):
        self.pos_filter = pos_filter
        self.keyword_lookup = []
        self.database = []
        self.idx_database = []

    def construct(self, keywords):
        # optional: define own keyword lookup
        # @params
        # keyword ==> list
        self.keyword_lookup = keywords

    def put_idx_data(self, data):
        # @params
        # data ==> list
        # ex: ["sentence", ...]
        s = time.time()
        if not self.keyword_lookup:
            logger.info("keyword_lookup is not defined, using keywords in data")
            keywords = set()
            for txt in data:
                clean_txt = self.pos_filter.filter(txt)
                for char in clean_txt:
                    keywords.add(char)
            self.keyword_lookup = list(keywords)

        size = 0
        self.database = data
        idx_database = []
        for txt in data:
            idx_array = []
            for idx, char in enumerate(self.keyword_lookup):
                if char in txt:
                    idx_array.append(idx)
            idx_database.append(idx_array)
            size += getsizeof(idx_array)
        self.idx_database = idx_database
        e = time.time()
        logger.debug("put_idx_data: time = {}".format(e - s))
        logger.debug("idx_database: size = {} bytes".format(size))

    def predict(self, txt):
        # @params
        # txt ==> str

        txt = self.pos_filter.filter(txt)
        idx_array = []
        for idx, char in enumerate(self.keyword_lookup):
            if char in txt:
                idx_array.append(idx)

        cand = []
        for idx, txt in enumerate(self.database):
            # cmp
            similar_point = 0
            for char_id in self.idx_database[idx]:
                for txt_char_idx in idx_array:
                    if char_id == txt_char_idx:
                        similar_point += 1
            different_point = -1 * (len(self.idx_database[idx]) - similar_point)
            if similar_point > 0:
                # similar_ratio = similar_point / len(self.idx_database[idx])
                different_ratio = different_point / len(self.idx_database[idx])
                cand.append((txt, similar_point, different_ratio))
        if not cand:
            return []
        else:
            cand = sorted(cand, key=lambda k: (k[1], k[2]), reverse=True)
            return cand
