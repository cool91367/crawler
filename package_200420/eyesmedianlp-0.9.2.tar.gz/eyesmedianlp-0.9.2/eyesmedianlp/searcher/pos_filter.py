# -*- coding: utf-8 -*-

# Created by JoJo. 2019.8.1

import re
import abc


# 提供能自定義要過濾的詞性
class POSFilter(abc.ABC):

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    @abc.abstractmethod
    def filter(self, txt):
        raise NotImplementedError


class StandardPOSFilter(POSFilter):

    def __init__(self, tokenizer):
        super().__init__(tokenizer)
        self.__define_filter_symbols()

    def __define_filter_symbols(self):
        # 要保留的詞性: 請查閱Hanlp詞性表
        self.pos_list = [r'a', r'n.*', r'g.*', r'f', r'i', r'h', r'k', r'l', r'v.*']
        # 要保留的例外字
        self.exc = r'不|被|沒'
        # 要去除的例外字
        self.fil = r'是|不是|是不是' \
                   r'|覺得|認為|想' \
                   r'|會|不會|會不會' \
                   r'|能|不能|能不能' \
                   r'|有|沒有|有沒有'

    def filter(self, txt):
        tokens = self.tokenizer.standard_tokenizer(txt)
        retain = []
        for token in tokens:
            if re.match("|".join(self.pos_list), token["nature"]) and not re.match(self.fil, token["word"]):
                retain.append(token["word"])
            else:
                if re.match(self.exc, token["word"]):
                    retain.append(token["word"])
        return "".join(retain)
