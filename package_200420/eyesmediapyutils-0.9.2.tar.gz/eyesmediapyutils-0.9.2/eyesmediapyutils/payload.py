# -*- coding: utf-8 -*-
import logging
import json
import datetime
from bson.objectid import ObjectId
from datetime import datetime
from eyesmediapyutils.datetime import DEFAULT_DATETIME_PATTERN

logger = logging.getLogger(__name__)


def obj_to_json(obj):
    return json.JSONDecoder().decode(JSONEncoder().encode(obj.__dict__))


class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        if isinstance(obj, datetime):
            return str(obj.strftime(DEFAULT_DATETIME_PATTERN))
        return json.JSONEncoder.default(self, obj)


class ReponsePayloadBulider(object):

    def __init__(self, properties):
        """
        初始化
        :param properties: 型態為dict，由config.ApplicationContext取得
        """
        self.properties = properties

    def bulid_from_exception(self, exception, data=None, paging=None, message_id=None, message_datetime=None, cost_time=None):
        """
        :param exception: eyesmediapyutils.exceptions.CommonRuntimeException
        :param data:
        :param paging:
        :return:
        """
        error_code = exception.code
        error_desc = self.properties.get(exception.code)
        if error_desc and exception.params and len(exception.params) > 0:
            error_desc = error_desc.format(exception.params)
        return self.bulid(error_code,
                          error_desc=error_desc,
                          data=data,
                          paging=paging,
                          message_id=message_id,
                          message_datetime=message_datetime
                          )

    def bulid(self, error_code, error_desc=None, data=None, paging=None, message_id=None, message_datetime=None, cost_time=None):
        """
        建立API回傳的內文
        :param error_code: 參照messages.properties
        :param error_desc: 參照messages.properties
        :param data: API所要回傳的資料，型態不拘
        :param paging: 分頁物件(utils.Paging)
        :return: dict
        """
        reponse_body = {
            # "messageId": message_id,
            # "messageDatetime": message_datetime,
            "errorCode": error_code,
            "errorDesc": error_desc
        }
        if message_id:
            reponse_body.setdefault("messageId", message_id)
        if message_datetime:
            reponse_body.setdefault("messageDatetime", message_datetime)
        if cost_time:
            reponse_body.setdefault("costTime", cost_time)

        if not error_desc:
            try:
                reponse_body["errorDesc"] = self.properties[error_code]
            except:
                logger.warning("error_code({}) not found message content...".format(error_code))

        if error_code[2:4] == "99":
            return reponse_body

        reponse_body["data"] = data

        if paging:
            reponse_body["paging"] = {
                "pageNo": paging.page_no,
                "totalPages": paging.total_page
            }

        return reponse_body
