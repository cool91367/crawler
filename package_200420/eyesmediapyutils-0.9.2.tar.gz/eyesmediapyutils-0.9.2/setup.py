# -*- coding: utf-8 -*-
import os
import sys
from setuptools import find_packages, setup, Command

install_requires = [
    "pytz==2018.7",
    "pandas>=0.23.4",
    "boto3==1.9.33",
    "botocore==1.12.33",
    "python-dateutil==2.7.5"
]


def read(fname):
    """Utility function to read the README file into the long_description."""
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


version_file = "version.py"
with open(version_file) as fp:
    exec(fp.read())

setup(
    name="eyesmediapyutils",
    version=__version__,
    author="eyesmedia",
    author_email="developer@eyesmedia.tw",
    description="eyesmedia deeplearning library",
    license="Copyright eyesmedia",
    py_modules=['eyesmediapyutils'],
    install_requires=install_requires,
    packages=find_packages(exclude=("tests",)),
    include_package_data=True,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
    ]
)
