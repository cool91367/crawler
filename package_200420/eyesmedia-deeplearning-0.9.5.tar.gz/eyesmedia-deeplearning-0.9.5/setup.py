# -*- coding: utf-8 -*-
import os
from setuptools import find_packages, setup

install_requires = [
    "absl-py==0.2.2",
    "boto==2.49.0",
    "boto3==1.9.33",
    "botocore==1.12.33",
    "bz2file==0.98",
    "certifi==2018.10.15",
    "chardet==3.0.4",
    "docutils==0.14",
    "gensim==3.8.1",
    "idna>=2.7",
    "jmespath==0.9.3",
    "nltk==3.3",
    "numpy>=1.16.0",
    "Pillow==5.3.0",
    "python-dateutil==2.7.5",
    "requests==2.20.0",
    "s3transfer==0.1.13",
    "scipy==1.1.0",
    "six>=1.11.0",
    "smart-open==1.8.4",
    "urllib3==1.24",
    "torch==1.2.0",
    "torchvision==0.4.0",
    "pandas>=0.24.2",
    "sklearn>=0.0",
    "tqdm>=4.19.9",
    "eyesmedianlp>=0.9.2"
]


def read(fname):
    """Utility function to read the README file into the long_description."""
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


version_file = "version.py"
with open(version_file) as fp:
    exec(fp.read())

setup(
    name="eyesmedia-deeplearning",
    version=__version__,
    author="eyesmedia",
    author_email="developer@eyesmedia.tw",
    description="eyesmedia deeplearning library",
    license="Copyright eyesmedia",
    py_modules=['eyesdeeplearning'],
    install_requires=install_requires,
    packages=find_packages(exclude=("tests",)),
    include_package_data=True,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
    ]
)
