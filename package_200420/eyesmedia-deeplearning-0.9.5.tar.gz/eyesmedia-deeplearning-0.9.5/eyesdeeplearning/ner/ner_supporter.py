# -*- coding: utf-8 -*-
import logging
import time
import random
import gc
import numpy as np
import time
import torch
import torch.nn as nn
import torch.optim as optim
import torch.autograd as autograd
# import matplotlib.pyplot as plt
import multiprocessing as mp
import traceback
from eyesdeeplearning.supporter.generic import TorchModelGenericSupporter, set_torch_manual_seed
from eyesdeeplearning.ner.model.bilstmcrf import BiLSTM_CRF
from eyesdeeplearning.ner.utils.metric import get_ner_fmeasure

SEED = 0
# torch.manual_seed(SEED)
# torch.cuda.manual_seed(SEED)
# np.random.seed(SEED)
# random.seed(SEED)

logger = logging.getLogger("eyesdeeplearning")

__version__ = torch.__version__

class Process(mp.Process): # catch exception from mp child process
    def __init__(self, *args, **kwargs):
        mp.Process.__init__(self, *args, **kwargs)
        self._pconn, self._cconn = mp.Pipe()
        self._exception = None

    def run(self):
        try:
            mp.Process.run(self)
            self._cconn.send(None)
        except Exception as e:
            tb = traceback.format_exc()
            self._cconn.send((e, tb))
            # raise e  # You can still rise this exception if you need to

    def exception(self):
        if self._pconn.poll():
            self._exception = self._pconn.recv()
        return self._exception

class NERSupporter(TorchModelGenericSupporter):

    def __init__(self, nn_params, data_provider):
        self.data_provider = data_provider
        self.model_file = nn_params["model_file"]
        self.plot_file = nn_params.get("plot_file")
        # logger.info("set thread num as:{}".format(mp.cpu_count()))
        # torch.set_num_threads(mp.cpu_count())
        super().__init__(nn_params)

    def _init_nn_model(self):

        dataset = self.data_provider.dataset
        if torch.cuda.is_available():
            dataset.HP_gpu = True
            n_cuda = torch.cuda.device_count()
            if n_cuda <= 1:
                model = BiLSTM_CRF(dataset).cuda() # single GPU
            else:
                model = nn.DataParallel(BiLSTM_CRF(dataset), device_ids=[0, 1])  # multi-GPUs
            logger.info("GPU state:{}, train on GPU ({})...".format(dataset.HP_gpu, n_cuda))
        else:
            model = BiLSTM_CRF(dataset)
            logger.info("GPU state:{}, device set as CPU...".format(dataset.HP_gpu))
        # dataset.show_data_summary()
        return model

    def parallel_train_model(self, callback=None):

        logger.info("train model start (parallel)...")
        dataset = self.data_provider.dataset
        dataset.show_data_summary()

        num_core = mp.cpu_count()
        logger.info("set thread num as:{}".format(num_core))
        torch.set_num_threads(num_core)

        train_instance_Ids = [dataset.train_Ids[i::num_core] for i in range(num_core)] #split train data by n_cores

        model = self.nn_model
        model.share_memory()
        logging.info("Parallel processes {}".format(num_core))

        # processes = []
        # for rank in range(num_core):
        #     p = mp.Process(target=self.train_model_mp(model, train_instance_Ids[rank], dataset))
        #     p.start()
        #     processes.append(p)
        # for p in processes:
        #     p.join()

        p = mp.Process(target=self.train_model_mp(model, dataset.train_Ids[:], dataset))
        p.start()
        p.join()

        logger.info('all child process done.')

    def train_model(self, callback=None):

        logger.info("train model start...")

        train_accs = []
        eval_accs = []
        train_times = []
        eval_times = []
        epoch_train_acc = 0
        dataset = self.data_provider.dataset
        dataset.show_data_summary()

        loss_function = nn.NLLLoss()
        parameters = [p for p in self.nn_model.parameters() if p.requires_grad]
        optimizer = optim.SGD(parameters, lr=dataset.HP_lr, momentum=dataset.HP_momentum)
        best_dev = -1
        check_point = 10
        # dataset.HP_iteration = 30  # epoch setting
        seg = True
        # start training
        for idx in range(dataset.HP_iteration):
            epoch_start = time.time()
            temp_start = epoch_start
            # print(("Epoch: %s/%s" % (idx, data.HP_iteration)))
            optimizer = self.__lr_decay(optimizer, idx, dataset.HP_lr_decay, dataset.HP_lr)
            instance_count = 0
            sample_id = 0
            sample_loss = 0
            batch_loss = 0
            total_loss = 0
            right_token = 0
            whole_token = 0
            random.shuffle(dataset.train_Ids)

            ## set model in train model
            self.nn_model.train()
            self.nn_model.zero_grad()

            batch_size = 1  ## current only support batch size = 1 to compulate and accumulate to data.HP_batch_size update weights
            batch_id = 0
            iter_size = 0
            train_num = len(dataset.train_Ids)
            total_batch = train_num // batch_size + 1
            for batch_id in range(total_batch):
                start = batch_id * batch_size
                end = (batch_id + 1) * batch_size

                if end > train_num:
                    end = train_num
                instance = dataset.train_Ids[start:end] #train instance
                if not instance:
                    continue

                gaz_list, \
                batch_word, \
                batch_biword, \
                batch_wordlen, \
                batch_wordrecover, \
                batch_char, \
                batch_charlen, \
                batch_charrecover, \
                batch_label, \
                mask = self.__batchify_with_label(instance, dataset.HP_gpu)
                # logger.info("nllLoss mask:{}".format(mask))


                instance_count += 1

                try: # multi-CPUs or single GPU w/o DataParallel # todo fix torch 1.2.0 bool issue
                    loss, tag_seq = self.nn_model.neg_log_likelihood_loss(gaz_list, batch_word, batch_biword, batch_wordlen, batch_char, batch_charlen, batch_charrecover, batch_label, mask)
                except: # multi-GPUs w/ DataParallel
                    loss, tag_seq = self.nn_model.module.neg_log_likelihood_loss(gaz_list, batch_word, batch_biword, batch_wordlen, batch_char, batch_charlen, batch_charrecover, batch_label, mask)

                right, whole = self.__predict_check(tag_seq, batch_label, mask)
                right_token += right
                whole_token += whole
                sample_loss += loss.item()
                total_loss += loss.item()
                batch_loss += loss

                if end % check_point == 0:
                    iter_size += 1
                    temp_time = time.time()
                    # temp_cost = temp_time - temp_start
                    temp_start = temp_time
                    # logger.info("Epoch({}):batch({}/{}) >>> Time: {}s; loss: {}; acc: {}/{}={}".format(
                    #     idx, end, total_batch, temp_cost, sample_loss/check_point, right_token, whole_token, right_token / whole_token
                    # ))
                    # sys.stdout.flush()
                    # sample_loss = 0

                # if end % dataset.HP_batch_size == 0:
                    batch_loss.backward()   # run backpropagation each 10 iteration
                    optimizer.step()
                    self.nn_model.zero_grad()
                    batch_loss = 0
                    temp_finish = time.time()
                    temp_cost = temp_finish - temp_start
                    acc = right_token / whole_token
                    epoch_train_acc += acc
                    logger.info("Epoch({}):batch({}/{}) >>> Time: {}s; loss: {}; acc: {}/{}={}".format(
                        idx, end, total_batch, temp_cost, sample_loss/check_point, right_token, whole_token, acc
                    ))
                    sample_loss = 0

            train_acc = epoch_train_acc / iter_size
            train_accs.append(train_acc)
            epoch_train_acc = 0

            epoch_finish = time.time()
            epoch_cost = epoch_finish - epoch_start
            logger.info("Epoch({}/{}): training finished. Time: {}s, speed: {}st/s,  total loss: {}".format(
                idx, dataset.HP_iteration, epoch_cost, train_num / epoch_cost, total_loss/total_batch
            ))

            speed, acc, p, r, f, _ = self.evaluate(dataset, dataset.dev_Ids)
            test_finish = time.time()
            test_cost = test_finish - epoch_finish
            logger.info("Epoch({}/{}): evaluate time: {}s, speed: {}st/s; acc: {}, p: {}, r: {}, f: {}, valid size:{}".format(
                idx, dataset.HP_iteration, test_cost, speed, acc, p, r, f, len(dataset.dev_Ids)
            ))

            current_score = f #if seg else acc
            if current_score > best_dev:
                logger.info("Exceed previous best eval score:{}".format(current_score))
                self.save_model(self.model_file)
                best_dev = current_score

            train_times.append(epoch_cost)
            eval_times.append(test_cost)
            eval_accs.append(f)

            gc.collect()

        # self.train_plot(train_accs, eval_accs, train_times, eval_times, dataset.HP_iteration)

    def __lr_decay(self, optimizer, epoch, decay_rate, init_lr):
        lr = init_lr * ((1 - decay_rate) ** epoch)
        logger.info("Learning rate is setted as: {}".format(lr))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        return optimizer

    def __batchify_with_label(self, input_batch_list, gpu, volatile_flag=False):
        """
            input: list of words, chars and labels, various length. [[words,biwords,chars,gaz, labels],[words,biwords,chars,labels],...]
                words: word ids for one sentence. (batch_size, sent_len)
                chars: char ids for on sentences, various length. (batch_size, sent_len, each_word_length)
            output:
                zero padding for word and char, with their batch length
                word_seq_tensor: (batch_size, max_sent_len) Variable
                word_seq_lengths: (batch_size,1) Tensor
                char_seq_tensor: (batch_size*max_sent_len, max_word_len) Variable
                char_seq_lengths: (batch_size*max_sent_len,1) Tensor
                char_seq_recover: (batch_size*max_sent_len,1)  recover char sequence order
                label_seq_tensor: (batch_size, max_sent_len)
                mask: (batch_size, max_sent_len)
        """
        batch_size = len(input_batch_list)
        words = [sent[0] for sent in input_batch_list]
        biwords = [sent[1] for sent in input_batch_list]
        chars = [sent[2] for sent in input_batch_list]
        gazs = [sent[3] for sent in input_batch_list]
        labels = [sent[4] for sent in input_batch_list]
        word_seq_lengths = torch.LongTensor(list(map(len, words)))
        max_seq_len = word_seq_lengths.max()

        if volatile_flag:
            with torch.no_grad():
                word_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
                biword_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
                label_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
                if "1.2" in __version__:
                    mask = autograd.Variable(torch.zeros((batch_size, max_seq_len))).bool()  # torch 1.2.0
                else:
                    mask = autograd.Variable(torch.zeros((batch_size, max_seq_len))).byte() # torch 1.1.0 and older

        else:
            word_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
            biword_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
            label_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len))).long()
            if "1.2" in __version__:
                mask = autograd.Variable(torch.zeros((batch_size, max_seq_len))).bool()  # torch 1.2.0
            else:
                mask = autograd.Variable(torch.zeros((batch_size, max_seq_len))).byte() # torch 1.1.0 and older

        for idx, (seq, biseq, label, seqlen) in enumerate(zip(words, biwords, labels, word_seq_lengths)):
            word_seq_tensor[idx, :seqlen] = torch.LongTensor(seq)
            biword_seq_tensor[idx, :seqlen] = torch.LongTensor(biseq)
            label_seq_tensor[idx, :seqlen] = torch.LongTensor(label)
            mask[idx, :seqlen] = torch.Tensor([1] * seqlen.cpu().numpy().tolist())

        word_seq_lengths, word_perm_idx = word_seq_lengths.sort(0, descending=True)
        word_seq_tensor = word_seq_tensor[word_perm_idx]
        biword_seq_tensor = biword_seq_tensor[word_perm_idx]
        ## not reorder label
        label_seq_tensor = label_seq_tensor[word_perm_idx]
        mask = mask[word_perm_idx]
        ### deal with char
        # pad_chars (batch_size, max_seq_len)
        pad_chars = [chars[idx] + [[0]] * (max_seq_len - len(chars[idx])).cpu().numpy().tolist() for idx in range(len(chars))]
        # pad_chars = [chars[idx] + [[0]] * (max_seq_len -len(chars[idx])) for idx in range(len(chars))]
        length_list = [list(map(len, pad_char)) for pad_char in pad_chars]
        max_word_len = max(list(map(max, length_list)))

        if volatile_flag:
            with torch.no_grad():
                char_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len, max_word_len))).long()
        else:
            char_seq_tensor = autograd.Variable(torch.zeros((batch_size, max_seq_len, max_word_len))).long()


        char_seq_lengths = torch.LongTensor(length_list)
        for idx, (seq, seqlen) in enumerate(zip(pad_chars, char_seq_lengths)):
            for idy, (word, wordlen) in enumerate(zip(seq, seqlen)):
                char_seq_tensor[idx, idy, :wordlen] = torch.LongTensor(word)
        char_seq_tensor = char_seq_tensor[word_perm_idx].view(batch_size * max_seq_len, -1)
        char_seq_lengths = char_seq_lengths[word_perm_idx].view(batch_size * max_seq_len, )
        char_seq_lengths, char_perm_idx = char_seq_lengths.sort(0, descending=True)
        char_seq_tensor = char_seq_tensor[char_perm_idx]
        _, char_seq_recover = char_perm_idx.sort(0, descending=False)
        _, word_seq_recover = word_perm_idx.sort(0, descending=False)

        ## keep the gaz_list in orignial order

        gaz_list = [gazs[i] for i in word_perm_idx]
        gaz_list.append(volatile_flag)
        if gpu:
            word_seq_tensor = word_seq_tensor.cuda()
            biword_seq_tensor = biword_seq_tensor.cuda()
            word_seq_lengths = word_seq_lengths.cuda()
            word_seq_recover = word_seq_recover.cuda()
            label_seq_tensor = label_seq_tensor.cuda()
            char_seq_tensor = char_seq_tensor.cuda()
            char_seq_recover = char_seq_recover.cuda()
            mask = mask.cuda()
        return gaz_list, \
               word_seq_tensor, \
               biword_seq_tensor, \
               word_seq_lengths, \
               word_seq_recover, \
               char_seq_tensor, \
               char_seq_lengths, \
               char_seq_recover, \
               label_seq_tensor, \
               mask

    def __predict_check(self, pred_variable, gold_variable, mask_variable):
        """
            input:
                pred_variable (batch_size, sent_len): pred tag result, in numpy format
                gold_variable (batch_size, sent_len): gold result variable
                mask_variable (batch_size, sent_len): mask variable
        """
        pred = pred_variable.cpu().data.numpy()
        gold = gold_variable.cpu().data.numpy()
        mask = mask_variable.cpu().data.numpy()
        overlapped = (pred == gold)
        right_token = np.sum(overlapped * mask)
        total_token = mask.sum()
        return right_token, total_token

    def recover_label(self, pred_variable, gold_variable, mask_variable, label_alphabet, word_recover):
        """
            input:
                pred_variable (batch_size, sent_len): pred tag result
                gold_variable (batch_size, sent_len): gold result variable
                mask_variable (batch_size, sent_len): mask variable
        """
        pred_variable = pred_variable[word_recover]
        gold_variable = gold_variable[word_recover]
        mask_variable = mask_variable[word_recover]
        batch_size = gold_variable.size(0)
        seq_len = gold_variable.size(1)
        mask = mask_variable.cpu().data.numpy()
        pred_tag = pred_variable.cpu().data.numpy()
        gold_tag = gold_variable.cpu().data.numpy()
        batch_size = mask.shape[0]
        pred_label = []
        gold_label = []
        for idx in range(batch_size):
            pred = [label_alphabet.get_instance(pred_tag[idx][idy]) for idy in range(seq_len) if mask[idx][idy] != 0]
            gold = [label_alphabet.get_instance(gold_tag[idx][idy]) for idy in range(seq_len) if mask[idx][idy] != 0]
            # print "p:",pred, pred_tag.tolist()
            # print "g:", gold, gold_tag.tolist()
            assert (len(pred) == len(gold))
            pred_label.append(pred)
            gold_label.append(gold)
        return pred_label, gold_label

    def evaluate(self, dataset, instances):
        # if name == "train":
        #     instances = data.train_Ids
        # elif name == "dev":
        #     instances = data.dev_Ids
        # elif name == 'test':
        #     instances = data.test_Ids
        # elif name == 'raw':
        #     instances = data.raw_Ids
        # elif name == 'predict':
        #     instances = data.predict_Ids
        # else:
        #     print("Error: wrong evaluate name,", name)
        right_token = 0
        whole_token = 0
        pred_results = []
        gold_results = []
        ## set model in eval model
        self.nn_model.eval()
        batch_size = 1
        start_time = time.time()
        train_num = len(instances)
        total_batch = train_num // batch_size + 1
        for batch_id in range(total_batch):
            start = batch_id * batch_size
            end = (batch_id + 1) * batch_size
            if end > train_num:
                end = train_num
            instance = instances[start:end]
            if not instance:
                continue
            gaz_list, \
            batch_word, \
            batch_biword, \
            batch_wordlen, \
            batch_wordrecover, \
            batch_char, \
            batch_charlen, \
            batch_charrecover, \
            batch_label, \
            mask = self.__batchify_with_label(instance, dataset.HP_gpu, True)

            tag_seq = self.nn_model(gaz_list,
                                    batch_word,
                                    batch_biword,
                                    batch_wordlen,
                                    batch_char,
                                    batch_charlen,
                                    batch_charrecover,
                                    mask)
            pred_label, gold_label = self.recover_label(tag_seq,
                                                        batch_label,
                                                        mask,
                                                        dataset.label_alphabet,
                                                        batch_wordrecover)
            pred_results += pred_label
            gold_results += gold_label
        decode_time = time.time() - start_time
        speed = len(instances) / decode_time
        acc, p, r, f = get_ner_fmeasure(gold_results, pred_results, dataset.tagScheme)
        return speed, acc, p, r, f, pred_results  # , tag_seq.tolist()[0]

    def predict(self, text, *args, **kwargs):

        # predict_start_time = time.time() ##

        self.nn_model.eval()

        with torch.no_grad():
            dataset = self.data_provider.dataset
            dataset.generate_instance_with_gaz(input_file=text, name="predict")
            input_ids = dataset.predict_Ids[0:]

            gaz_list, \
            batch_word, \
            batch_biword, \
            batch_wordlen, \
            batch_wordrecover, \
            batch_char, \
            batch_charlen, \
            batch_charrecover, \
            batch_label, \
            mask = self.__batchify_with_label(input_ids, dataset.HP_gpu, True)

            # batchify_time = time.time()  ##
            # logger.info("get batchify label time:{}".format(batchify_time - predict_start_time))  # 0.29730892181396484

            set_torch_manual_seed(SEED)

            # with torch.no_grad():
            pre_data = self.nn_model(gaz_list, batch_word, batch_biword, batch_wordlen, batch_char, batch_charlen,
                                     batch_charrecover, mask)

            # pre_data_time = time.time()  ##
            # logger.info("get pre_data time:{}".format(pre_data_time - batchify_time))  # 1.0274841785430908

            # logger.info("prediction data:{}".format(pre_data))
            pred_label, gold_label = self.recover_label(pre_data,
                                                        batch_label,
                                                        mask,
                                                        dataset.label_alphabet,
                                                        batch_wordrecover)

            # get_label_time = time.time()  ##
            # logger.info("get pred label time:{}".format(get_label_time - pre_data_time))

            # speed, acc, p, r, f, pred_label = self.evaluate(dataset, dataset.predict_Ids)
            # logger.info("speed:{}st/s; acc: {}, p: {}, r: {}, f: {}".format(speed, acc, p, r, f))
            # logger.info("predict label is {}".format(pred_label[0]))
            if None in pred_label[0]:
                pred_label[0] = []
            pred = self.__label2word(text, pred_label[0])  # array([[labels]])

            # pred_res_time = time.time()
            # logger.info("get pred res time:{}".format(pred_res_time - get_label_time))

            # logger.info("predict label format {}".format(pred))
            return pred


    def __label2word(self, text, predict_tags):
        offset = 0
        jump_flag = -1
        tags_len = len(predict_tags)
        words = []
        for word, tag in zip(text, predict_tags):
            if offset < jump_flag:
                offset += 1
                continue

            prefix = tag[0]
            if prefix not in ["B", "S"]:
                offset += 1
                continue

            if prefix == "S":
                labels = tag.split("-")
                labels = labels[1] if len(labels) > 0 else labels
                words.append((text[offset:], labels, [offset, offset]))
                offset += 1
                continue

            if prefix == "B":
                labels = tag.split("-")
                labels = labels[1] if len(labels) > 0 else labels
                if offset + 1 >= tags_len:  # 代表最後一個，不用再去找剩下的tag
                    words.append((text[offset:], labels, [offset, offset]))
                    break

                w_idx_s = offset
                mid_prefix = "I-{}".format(labels)
                end_prefix = "E-{}".format(labels)
                end_prefix_idx = 0
                for i, t in enumerate(predict_tags[offset:]):
                    if t == tag:
                        continue
                    if t != mid_prefix and t != end_prefix:
                        end_prefix_idx = i - 1
                        break
                    if t == end_prefix:
                        end_prefix_idx = i
                        break
                w_idx_e = w_idx_s + end_prefix_idx
                jump_flag = w_idx_e + 1
                offset += 1
                words.append((text[w_idx_s:w_idx_e + 1], labels, [w_idx_s, w_idx_e]))
                continue

        return words

    def train_model_mp(self, nn_model, train_instance, dataset):

        set_torch_manual_seed(SEED)

        parameters = [p for p in nn_model.parameters() if p.requires_grad]
        optimizer = optim.SGD(parameters, lr=dataset.HP_lr, momentum=dataset.HP_momentum)
        best_dev = -1
        dataset.HP_iteration = 2  # set small epoch for test
        seg = True
        # start training
        for idx in range(dataset.HP_iteration):
            epoch_start = time.time()

            temp_start = epoch_start
            logger.info("Epoch:{}/{}".format(idx, dataset.HP_iteration))
            optimizer = self.__lr_decay(optimizer, idx, dataset.HP_lr_decay, dataset.HP_lr)
            instance_count = 0
            sample_id = 0
            sample_loss = 0
            batch_loss = 0
            total_loss = 0
            right_token = 0
            whole_token = 0
            random.shuffle(train_instance)

            ## set model in train model
            nn_model.train()
            nn_model.zero_grad()
            batch_size = 1  ## current only support batch size = 1 to compulate and accumulate to data.HP_batch_size update weights
            batch_id = 0
            train_num = len(train_instance)
            total_batch = train_num // batch_size + 1

            for batch_id in range(total_batch):
                start = batch_id * batch_size
                end = (batch_id + 1) * batch_size
                if end > train_num:
                    end = train_num
                instance = train_instance[start:end]  # train instance

                if not instance:
                    continue

                gaz_list, \
                batch_word, \
                batch_biword, \
                batch_wordlen, \
                batch_wordrecover, \
                batch_char, \
                batch_charlen, \
                batch_charrecover, \
                batch_label, \
                mask = self.__batchify_with_label(instance, dataset.HP_gpu)

                instance_count += 1
                loss, tag_seq = nn_model.neg_log_likelihood_loss(gaz_list, batch_word, batch_biword,
                                                                 batch_wordlen, batch_char, batch_charlen,
                                                                 batch_charrecover, batch_label, mask)

                right, whole = self.__predict_check(tag_seq, batch_label, mask)
                right_token += right
                whole_token += whole
                sample_loss += loss.item()
                total_loss += loss.item()
                batch_loss += loss
                check_point = 10

                if end % check_point == 0:
                    temp_time = time.time()
                    temp_cost = temp_time - temp_start
                    temp_start = temp_time

                    # if end % dataset.HP_batch_size == 0:
                    batch_loss.backward()
                    optimizer.step()
                    nn_model.zero_grad()


                    logger.info("Epoch({}):batch({}/{}) >>> Time: {}s; loss: {}; acc: {}/{}={}".format(
                        idx, end, total_batch, temp_cost, sample_loss/check_point, right_token, whole_token,
                        (right_token + 0.) / whole_token
                    ))

                    sample_loss = 0
                    batch_loss = 0

            epoch_finish = time.time()
            epoch_cost = epoch_finish - epoch_start
            logger.info("Epoch({}/{}): training finished. Time: {}s, speed: {}st/s,  total loss: {}".format(
                idx, dataset.HP_iteration, epoch_cost, train_num / epoch_cost, total_loss/total_batch
            ))

            eval_start = time.time()
            speed, acc, p, r, f, _ = self.evaluate(dataset, dataset.dev_Ids)
            eval_finish = time.time()
            eval_cost = eval_finish - eval_start

            logger.info(
                "MP training: evaluate time: {}s, speed: {}st/s; acc: {}, p: {}, r: {}, f: {}, valid size:{}".format(
                    eval_cost, speed, acc, p, r, f, len(dataset.dev_Ids)
                ))

            current_score = f

            if current_score > best_dev:
                logger.info("Exceed previous best eval score:{}".format(current_score))
                self.save_model(self.model_file)
                best_dev = current_score

            # del nn_model

    # def train_plot(self, train_acc, eval_acc, train_time, eval_time, epoch_size):
    #     train_acc = [round(float(i), 2) for i in train_acc]
    #     eval_acc = [round(float(i), 2) for i in eval_acc]
    #
    #     train_time = [round(float(i), 2) for i in train_time]
    #     eval_time = [round(float(i), 2) for i in eval_time]
    #     epoch = range(epoch_size)
    #
    #     plt.figure(222)
    #     plt.subplot(211)
    #
    #     plt.plot(epoch, train_acc, label="train")
    #     for a, b in zip(epoch, train_acc):
    #         plt.text(a, b, b, ha='center', color='blue', va='bottom', fontsize=8)
    #
    #     plt.plot(epoch, eval_acc, label="eval")
    #     for a, b in zip(epoch, eval_acc):
    #         plt.text(a, b, b, ha='center', color='red', va='top', fontsize=8)
    #
    #     plt.ylabel(' accuracy (%)')
    #     plt.legend()
    #     plt.title('NER Training Result')
    #
    #     plt.subplot(212)
    #
    #     plt.plot(range(epoch_size), train_time, label="train")
    #     for a, b in zip(epoch, train_time):
    #         plt.text(a, b, b, ha='center', color='blue', va='bottom', fontsize=8)
    #
    #     plt.plot(range(epoch_size), eval_time, label="eval")
    #     for a, b in zip(epoch, eval_time):
    #         plt.text(a, b, b, ha='center', color='red', va='top', fontsize=8)
    #
    #     plt.xlabel('epoch')
    #     plt.ylabel('time cost (s)')
    #     plt.savefig(self.plot_file)


