# -*- coding: utf-8 -*-
import logging
import numpy as np
import time
import pickle
import itertools
import torch
import pandas as pd
import multiprocessing as mp
from eyesdeeplearning.dataset.generic import TorchDatasetProvider
from eyesdeeplearning.ner.utils.data import Data
from eyesdeeplearning.features.word_embedding import WordEmbedding

logger = logging.getLogger("eyesdeeplearning")


class NERDatasetProvider(TorchDatasetProvider):

    def __init__(self):
        self.dataset = None
        self.eval_rate = None
        torch.set_num_threads(mp.cpu_count())

    def load_embed_models(self, c2v_model, w2v_model):
        self.char_embedding = WordEmbedding(c2v_model)
        self.word_embedding = WordEmbedding(w2v_model)

    def load_annotation_data(self, fname):
        with open(fname, 'r', encoding='utf-8') as f:
            data_set = f.readlines()
            logger.info("load annotation data from {} success".format(fname))
            return data_set

    def enable_evaluate(self, eval_rate):
        self.eval_rate = eval_rate

    # def save(self, fname, iszip=True):
    #     """ over write """
    #     with open(fname, 'wb') as fp:
    #         pickle.dump(self._save_dataset(), fp)
    #     logger.info("save dataset to {} success".format(fname))

    # def load(self, fname, iszip=True):
    #     """ over write """
    #     with open(fname, 'rb') as fp:
    #         dataset = pickle.load(fp)
    #     self._load_dataset(dataset)
    #     logger.info("load dataset from {} success".format(fname))

    def _save_dataset(self):
        return {
            "dataset": self.dataset,
            "eval_rate": self.eval_rate
        }

    def _load_dataset(self, dataset):
        self.dataset = dataset["dataset"]
        self.eval_rate = dataset["eval_rate"]

    def train(self, train_datas):
        assert self.char_embedding or self.word_embedding, "please use load_embed_models founction before train..."
        logger.info("start training dataset")
        dataset = Data()
        dataset.HP_use_char = False
        dataset.use_bigram = False

        # 建立 word index dict
        index2word_set = set(self.word_embedding.model.wv.index2word)
        for word in index2word_set:
            dataset.gaz.insert(word, "one_source")

        # 建立 Word character lattice
        dataset.build_alphabet(input_file=None, input_data=train_datas)
        dataset.build_gaz_alphabet(input_file=None, input_data=train_datas)
        dataset.fix_alphabet()

        #將train_data切成train, valid data sets
        train_content, valid_content = dataset.split_data(train_datas, shuffle=True, split_rate=0.9)

        # 將Word character lattice轉換成對應的index id
        dataset.generate_instance_with_gaz(input_file=None, name="train", input_data=train_content)
        dataset.generate_instance_with_gaz(input_file=None, name="dev", input_data=valid_content)
        # data.generate_instance_with_gaz(test_file, 'test')

        # build_char_pretrain_emb
        dataset.pretrain_word_embedding, dataset.word_emb_dim = self.__build_pretrain_embedding(self.char_embedding, dataset.word_alphabet, dataset.norm_word_emb)
        # build_biword_pretrain_emb
        dataset.pretrain_biword_embedding, dataset.biword_emb_dim = self.__build_pretrain_embedding(None, dataset.biword_alphabet, dataset.norm_biword_emb)
        # build_word_pretrain_emb
        dataset.pretrain_gaz_embedding, dataset.gaz_emb_dim = self.__build_pretrain_embedding(self.word_embedding, dataset.gaz_alphabet, dataset.norm_gaz_emb)

        logger.info("training dataset success")
        dataset.show_data_summary()
        self.dataset = dataset

    def __norm2one(self, vec):
        root_sum_square = np.sqrt(np.sum(np.square(vec)))
        return vec / root_sum_square

    def __build_pretrain_embedding(self, embed_obj, word_alphabet, norm=True):
        start_time = time.time()
        if embed_obj:
            embedd_dict = embed_obj.load_pretrain_embedding()
            embedd_dim = embed_obj.model_dimension
        else:
            # default
            embedd_dim = 256
            embedd_dict = dict()

        scale = np.sqrt(3.0 / embedd_dim)
        pretrain_emb = np.empty([word_alphabet.size(), embedd_dim])
        perfect_match = 0
        case_match = 0
        not_match = 0
        for word, index in word_alphabet.instance2index.items():
            if word in embedd_dict:
                if norm:
                    pretrain_emb[index, :] = self.__norm2one(embedd_dict[word])
                else:
                    pretrain_emb[index, :] = embedd_dict[word]
                perfect_match += 1
            elif word.lower() in embedd_dict:
                if norm:
                    pretrain_emb[index, :] = self.__norm2one(embedd_dict[word.lower()])
                else:
                    pretrain_emb[index, :] = embedd_dict[word.lower()]
                case_match += 1
            else:
                pretrain_emb[index, :] = np.random.uniform(-scale, scale, [1, embedd_dim])
                not_match += 1
        pretrained_size = len(embedd_dict)
        cost_time = time.time() - start_time
        logger.info("build pretrain embedding(cost time:{}/s): word:{}, prefect match:{}, case_match:{}, oov:{}%({}/{})".format(
            cost_time, pretrained_size, perfect_match, case_match, (not_match + 0.) / word_alphabet.size(), not_match, word_alphabet.size()
        ))
        return pretrain_emb, embedd_dim

class NERDatasetGenerator():
    def flatten(self, entity_list):
        result = []
        for i in entity_list:
            if isinstance(i, str):
                result.append(i)
            else:
                result.extend(self.flatten(i))
        return result

    def find_word_idx(self, w, s):
        return [n for n in range(len(s)) if s.find(w, n) == n]

    def word2iboe(self, word, entity):
        final_entity = list()
        prefix = ['B-', 'I-', 'E-', 'S-']
        if len(word) == 2:
            final_entity.append(prefix[0] + entity)
            final_entity.append(prefix[2] + entity)
        elif len(word) > 2:
            final_entity.append(prefix[0] + entity)
            i_tag = [prefix[1] + entity] * (len(word) - 2)
            final_entity.append(i_tag)
            final_entity.append(prefix[2] + entity)
            final_entity = [x for x in self.flatten(final_entity)]
        elif len(word) == 1:
            final_entity.append(prefix[3] + entity)
        else:
            pass
        return final_entity

    def find_space_idx(self, the_list, val):
        retval = []
        last = 0
        while val in the_list[last:]:
            i = the_list[last:].index(val)
            retval.append(last + i)
            last += i + 1
        return retval

    def toolbox_sent_tag_mapping(self, anno_res):
        convert_sent = []
        for dicts in anno_res:
            try:
                sent_len = len(dicts['ner_content'][0])
                original_sent = dicts['ner_content']
                original_tag = ['O' * (sent_len)]
                original_tag = [word for line in original_tag[0] for word in line.split()]

                for entity in dicts['entities']:
                    start_idx = int(entity['article_index'][0])
                    end_idx = int(entity['article_index'][1])
                    entity_label = self.word2iboe(entity['word'], entity['entities'][0]['code'])
                    original_tag[start_idx:end_idx] = entity_label
                assert sent_len == len(original_tag)
                space_idx = self.find_space_idx(original_sent[0], ' ')
                replaced_sent = [i for j, i in enumerate(list(original_sent[0])) if j not in space_idx]
                replaced_sent = ["".join(replaced_sent)]
                replaced_tag = [i for j, i in enumerate(original_tag) if j not in space_idx]
                convert_sent.append([replaced_sent, replaced_tag])
                assert len(replaced_sent[0]) == len(replaced_tag)
            except:
                pass

        res = list(k for k, _ in itertools.groupby(convert_sent))
        data_df = pd.DataFrame(res, columns=["sent", "tag"])
        return data_df

    def data_generator(self, dataset, filename):
        saved_path = filename
        print(saved_path)
        with open(str(saved_path), 'w') as f:
            for sentence, tags in zip(dataset.sent, dataset.tag):
                for char, tag in zip(sentence[0], tags):
                    f.write(char)
                    f.write(' ')
                    f.write(tag)
                    f.write('\n')
                f.write('\n')