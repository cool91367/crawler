# -*- coding: utf-8 -*-
import logging
import os

logger = logging.getLogger("eyesdeeplearning")

PACKAGE_PATH = os.path.dirname(os.path.realpath(__file__))
VOCAB_FILE = os.path.join(PACKAGE_PATH, "vocab.txt")


def load_base_vocab():
    vocab_dict = {}
    with open(VOCAB_FILE, encoding="utf-8") as f:
        char_list = f.read().split('\n')
        for idx, v in enumerate(char_list):
            vocab_dict.setdefault(v, idx)
    logger.info("read base vocab file({}) success, data size is {}".format(VOCAB_FILE, len(vocab_dict)))
    return vocab_dict


def load_custom_vocab(vocab_file):
    if not os.path.exists(vocab_file) or not os.path.isfile(vocab_file):
        raise FileNotFoundError("customization vocab file({}) not found or not a file type...".format(vocab_file))
    vocab_dict = {}
    with open(vocab_file, encoding="utf-8") as f:
        char_list = f.read().split('\n')
        for idx, v in enumerate(char_list):
            vocab_dict.setdefault(v, idx)
    logger.info("read customization vocab file({}) success, data size is {}".format(VOCAB_FILE, len(vocab_dict)))
    return vocab_dict
