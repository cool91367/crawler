# -*- coding: utf-8 -*-
import logging

logger = logging.getLogger("eyesdeeplearning")


class IBOEUtils(object):

    @staticmethod
    def flatten(entity_list):
        result = []
        for i in entity_list:
            if isinstance(i, str):
                result.append(i)
            else:
                result.extend(IBOEUtils.flatten(i))
        return result

    @staticmethod
    def word2iboe(word, entity):
        final_entity = list()
        prefix = ['B-', 'I-', 'E-', 'S-']
        if len(word) == 2:
            final_entity.append(prefix[0] + entity)
            final_entity.append(prefix[2] + entity)
        elif len(word) > 2:
            final_entity.append(prefix[0] + entity)
            i_tag = [prefix[1] + entity] * (len(word) - 2)
            final_entity.append(i_tag)
            final_entity.append(prefix[2] + entity)
            final_entity = [x for x in IBOEUtils.flatten(final_entity)]
        elif len(word) == 1:
            final_entity.append(prefix[3] + entity)
        else:
            pass
        # elif len(word) < 2:
        # pass
        return final_entity
