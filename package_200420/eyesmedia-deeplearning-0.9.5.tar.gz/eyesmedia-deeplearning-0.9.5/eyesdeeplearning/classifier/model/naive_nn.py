import logging
import torch
import torch.nn as nn
import torch.nn.functional as F


class NaiveNN(nn.Module):
    def __init__(self, args):
        super(NaiveNN, self).__init__()
        C = args["class-number"]
        D = args["embed-dimension"]

        self.fc = nn.Linear(D, C)
        self.device = args["device"]

    def forward(self, x):
        # if self.device == "cuda":
        #     x = torch.cuda.FloatTensor(x)
        x = x.squeeze(1)
        logit = self.fc(x)  # (N, C)
        return logit
