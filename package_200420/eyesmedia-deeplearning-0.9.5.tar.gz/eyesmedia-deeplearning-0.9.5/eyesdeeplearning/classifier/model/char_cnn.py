# -*- coding: utf-8 -*-

# Modified from: (Kim, 2014) Convolutional Neural Networks for Sentence Classification

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.autograd import Variable

logger = logging.getLogger("eyesdeeplearning")


class CharCNN(nn.Module):

    def __init__(self, args):
        super(CharCNN, self).__init__()
        logger.info("initialize CharCNN, params is {}".format(args))
        self.args = args

        V = args["embed-num"]
        D = args["embed-dimension"]
        C = args["class-number"]
        Ci = 1
        Co = args["kernel-number"]
        Ks = args["kernel-sizes"]

        self.device = args["device"]

        self.embed = nn.Embedding(V, D, padding_idx=0)
        # if args["pre-trained"]:
        #     weights = torch.Tensor(args["pre-trained-matrix"])
        #     self.embed.from_pretrained(weights)

        # self.convs1 = [nn.Conv2d(Ci, Co, (K, D)) for K in Ks]
        self.convs1 = nn.ModuleList([nn.Conv2d(Ci, Co, (K, D)) for K in Ks])
        self.dropout = nn.Dropout(args["dropout-rate"])
        self.fc1 = nn.Linear(len(Ks) * Co, C)

    def conv_and_pool(self, x, conv):
        x = F.relu(conv(x)).squeeze(3)  # (N, Co, W)
        x = F.max_pool1d(x, x.size(2)).squeeze(2)
        return x

    def forward(self, x):

        # if self.device == "cuda":
        #     x = torch.cuda.LongTensor(x)

        x = self.embed(x)  # (N, W, D)

        x = x.unsqueeze(1)  # (N, Ci, W, D)

        x = [F.relu(conv(x)).squeeze(3) for conv in self.convs1]  # [(N, Co, W), ...]*len(Ks)

        x = [F.max_pool1d(i, i.size(2)).squeeze(2) for i in x]  # [(N, Co), ...]*len(Ks)

        x = torch.cat(x, 1)

        x = self.dropout(x)  # (N, len(Ks)*Co)

        logit = self.fc1(x)  # (N, C)
        return logit

    def embedding(self, x):
        x = self.embed(x)

        x = list(torch.unbind(x, dim=2))

        x = torch.cat(x, 1)

        return x

    def cnn_features(self, x):

        x = self.embed(x)  # (N, W, D)

        x = x.unsqueeze(1)  # (N, Ci, W, D)

        x = [F.relu(conv(x)).squeeze(3) for conv in self.convs1]  # [(N, Co, W), ...]*len(Ks)

        x = [F.max_pool1d(i, i.size(2)).squeeze(2) for i in x]  # [(N, Co), ...]*len(Ks)

        x = torch.cat(x, 1)

        return x
