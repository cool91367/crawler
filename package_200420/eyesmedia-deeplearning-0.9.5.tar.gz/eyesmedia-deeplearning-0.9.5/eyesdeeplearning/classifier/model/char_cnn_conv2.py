# -*- coding: utf-8 -*-

# Created by JoJo, inspired from (Kim, 2014) Convolutional Neural Networks for Sentence Classification

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

logger = logging.getLogger("eyesdeeplearning")


class CharCNNConv2(nn.Module):

    def __init__(self, args):
        super(CharCNNConv2, self).__init__()
        logger.info("initialize CharCNNConv2, params is {}".format(args))
        self.args = args

        V = args["embed-num"]
        D = args["embed-dimension"]
        C = args["class-number"]
        Ci = 1
        Co = args["kernel-number"]
        Ks = args["kernel-sizes"]

        self.device = args["device"]

        self.embed = nn.Embedding(V, D, padding_idx=0)

        self.convs1 = nn.ModuleList([nn.Conv2d(Ci, Co, (K, D)) for K in Ks])

        self.convs2 = nn.ModuleList([nn.Conv2d(Ci, 256, (K, Co)) for K in Ks])

        self.dropout = nn.Dropout(args["dropout-rate"])

        self.fc1 = nn.Linear(len(Ks) * (256 + Co), 256 + Co)
        self.fc2 = nn.Linear(256 + Co, C)

    def conv_and_pool(self, x, conv):
        x = F.relu(conv(x)).squeeze(3)  # (N, Co, W)
        x = F.max_pool1d(x, x.size(2)).squeeze(2)
        return x

    def forward(self, x):

        # if self.device == "cuda":
        #     x = torch.cuda.LongTensor(x)

        x = self.embed(x)  # (N, W, D)

        # if self.args["static"]:
        #     x = Variable(x)

        x = x.unsqueeze(1)  # (N, Ci, W, D)

        # print(x.shape)

        x = [F.relu(conv(x)).squeeze(3) for conv in self.convs1]  # [(N, Co, W), ...]*len(Ks)
        x = [F.max_pool1d(i, i.size(2)).squeeze(2) for i in x]  # [(N, Co), ...]*len(Ks)

        x0 = torch.cat(x, 1)

        x = torch.stack(x, dim=1)
        x = torch.unsqueeze(x, 1)

        # print(x.shape)

        x = [F.relu(conv(x)).squeeze(3) for conv in self.convs2]
        x = [F.max_pool1d(i, i.size(2)).squeeze(2) for i in x]  # [(N, Co), ...]*len(Ks)

        x = torch.cat(x, 1)

        x = self.dropout(x)  # (N, len(Ks)*Co)
        x0 = self.dropout(x0)

        x = torch.cat([x, x0], dim=1)

        tmp = self.fc1(x)  # (N, C)
        logit = self.fc2(tmp)

        return logit
