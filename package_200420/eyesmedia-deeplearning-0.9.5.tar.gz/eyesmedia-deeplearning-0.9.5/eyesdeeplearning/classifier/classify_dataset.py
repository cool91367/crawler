# -*- coding: utf-8 -*-
import logging
import torch
import random
import time
import numpy as np
from tqdm import tqdm
import torch.utils.data as data
from eyesdeeplearning.dict import load_base_vocab
from eyesdeeplearning.dataset.generic import TorchDatasetProvider

# chinese_bert_model_path = '/Users/admin/open-source-git/chinese_L-12_H-768_A-12'


logger = logging.getLogger("eyesdeeplearning")

VALIDATION_RATE = 0.1


class ClassifyDataset(data.Dataset):

    def __init__(self, feature, target, char_level=False):
        self.target = torch.tensor(target)
        if not char_level:
            self.data = torch.tensor(feature).float()
        else:
            self.data = torch.LongTensor(feature)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index], self.target[index]


class ClassifyDatasetProvider(TorchDatasetProvider):

    # def timer(func):
    #     def time_record(*args, **kwargs):
    #         start_time = time.time()
    #         result = func(*args, **kwargs)
    #         end_time = time.time()
    #         run_time = end_time - start_time
    #         logging.info("runs in {}s".format(run_time))
    #         return result
    #     return time_record

    def __init__(self, tokenizer, cnn_version):
        self.tokenizer = tokenizer
        self.bert_tokenizer = None
        self.w2v_model = None
        self.index2word_set = None
        self.bert_model = None
        self.target_lookup = None
        self.target_dict = None
        self.features = None
        self.target = None
        self.char_level = True
        self.char_dict = {}
        self.cnn_version = cnn_version  # for en-version

        # For divide train and validation set
        self.to_train = None
        self.size = None  # total

        # Parameters
        self.settings = {
            'embed_dimension': 256,  # default
            'char_dict_size': None,
            'doc_size': 30
        }

    def enable_bert(self, bert_tokenizer, bert_model):
        self.char_level = True
        self.bert_tokenizer = bert_tokenizer
        self.bert_model = bert_model
        self.settings["embed_dimension"] = 768

    def enable_word_embedding(self, w2v_model):
        self.char_level = False
        self.w2v_model = w2v_model
        self.settings["embed_dimension"] = w2v_model.vector_size
        self.index2word_set = set(self.w2v_model.wv.index2word)
        logger.info("classify dataset enable word embedding, disable char level...")

    def _create_vocab(self, text_list):
        self.char_dict = load_base_vocab()
        # vocab = []
        # max = self.settings["doc_dim"]
        # for text in text_list:
        #     vocab.extend(list(text.lower()))
        #     if len(text) > max:
        #         self.settings["doc_dim"] = len(text)
        # vocab = list(set(vocab))
        # vocab_size = len(self.char_dict)
        # add_size = 0
        # for idx, v in enumerate(vocab):
        #     if self.char_dict.get(v):
        #         continue
        #     self.char_dict[v] = vocab_size + add_size
        #     add_size += 1
        #
        self.settings['char_dict_size'] = len(self.char_dict)
        # self.settings["doc_dim"] = max
        # logger.info("_create_vocab success, vocab_size is {}, add_size is {}, total is {}".format(vocab_size, add_size, len(self.char_dict)))

    def _save_dataset(self):
        return {
            "target_lookup": self.target_lookup,
            "target_dict": self.target_dict,
            "features": self.features,
            "target": self.target,
            "size": self.size,  # features size
            "settings": self.settings,
            "char_level": self.char_level,
            "char_dict": self.char_dict
        }

    def _load_dataset(self, dataset):
        self.target_lookup = dataset.get("target_lookup")
        self.target_dict = dataset["target_dict"]
        self.features = dataset["features"]
        self.target = dataset["target"]
        self.size = dataset["size"]  # features size
        self.settings = dataset["settings"]
        self.char_level = dataset["char_level"]
        self.char_dict = dataset["char_dict"]

        if not self.target_lookup:
            self.target_lookup = dataset.get("intent_lookup")
        if not self.settings.get("embed_dimension"):
            self.settings.setdefault("embed_dimension", self.settings.get("word_dim"))
        if not self.settings.get("doc_size"):
            self.settings.setdefault("doc_size", self.settings.get("doc_dim"))

    def train(self, train_data):
        """
        :param train_data: {target1: [featureA, featureB], target2: [featureA, featureB], ...}
        :return:
        """
        if self.char_level:
            logger.info("create dataset vocab...")
            self._create_vocab([v for d in train_data.values() for v in d])

        logger.info("start training dataset, setting is {}".format(self.settings))

        # If exists, we can directly convert "string" to "id"
        if self.target_dict and self.target_lookup:
            # todo... retrain get a higher score?????
            # Train new
            targets = []
            feature_vec = []
            cnt = 0
            for key, values in train_data.items():
                cnt += len(values)
            with tqdm(total=cnt) as pbar:
                for key, values in train_data.items():
                    # turn raw input to well-cut features
                    targets.extend([key] * len(values))
                    feature_vec.extend(list(map(self.feature2vec, values)))
                    pbar.update(len(values))

            # copy old data
            old_to_train = int(self.size * (1 - VALIDATION_RATE))
            old_validation_features = self.features[old_to_train:]
            old_validation_target = self.target[old_to_train:]

            # check if there are new intents
            self.target = [self.target_dict[intent] for intent in targets]
            self.features = feature_vec
            retrain_size = len(self.target)

            # shuffle (for validation)
            s_time = time.time()
            tmp = list(zip(self.features, self.target))
            random.shuffle(tmp)
            self.features, self.target = zip(*tmp)
            e_time = time.time()
            logging.info("Shuffle time: {}".format(e_time - s_time))
            logger.info("dataset training finish, feature_size is {}, setting is {}".format(self.size, self.settings))
            self.features, self.target = list(self.features), list(self.target)
            # extension
            self.target.extend(old_validation_target)
            self.features.extend(old_validation_features)

            self.to_train = retrain_size
            self.size = len(self.target)

        else:
            targets = []
            feature_vec = []
            # feature_size = 0
            cnt = 0
            for key, values in train_data.items():
                cnt += len(values)
            with tqdm(total=cnt) as pbar:
                for key, values in train_data.items():
                    # turn raw input to well-cut features
                    targets.extend([key] * len(values))
                    feature_vec.extend(list(map(self.feature2vec, values)))
                    pbar.update(len(values))

            # assert feature_vec, targets
            self.features = feature_vec
            self.size = len(feature_vec)

            # data size per train must be larger than 1!
            if self.size < 2:
                raise ValueError('Sorry! You should prepare at least 2 data for training!')
            self.to_train = int(self.size * (1 - VALIDATION_RATE))  # ex. 9 * 0.9 = 8.1 => 8

            # store intent lookup and intent dictionary
            target_lookup = list(set(targets))
            target_dict = {}
            for idx, intent in enumerate(target_lookup):
                target_dict[intent] = idx

            target_idx = [target_dict[intent] for intent in targets]
            # for intent in targets:
            #     target_idx.append(target_dict[intent])

            self.target_lookup = target_lookup
            self.target_dict = target_dict
            self.target = target_idx

            # shuffle (for validation)
            s_time = time.time()
            tmp = list(zip(self.features, self.target))
            random.shuffle(tmp)
            self.features, self.target = zip(*tmp)
            self.features, self.target = list(self.features), list(self.target)
            e_time = time.time()
            logging.info("Shuffle time: {}".format(e_time - s_time))
            logger.info("dataset training finish, feature_size is {}, setting is {}".format(self.size, self.settings))

    def feature2vec(self, sent):

        vec = []
        if self.cnn_version == "char_cnn" or self.cnn_version == "char_cnn_conv2":
            if not self.char_dict:
                raise ValueError("plz enable_char_level before training...")

            tokens = list(sent)
            # 對每個字元分別給於one-hot向量
            vec = [self.char_dict[token] if token in self.char_dict else 0 for token in tokens]
            # for token in tokens:
            #     if token in self.char_dict:
            #         vec.append(self.char_dict[token])
            #     else:
            #         vec.append(0)

            # padding: 補上零的字向量讓矩陣長度固定
            vec_len = len(vec)
            if self.settings['doc_size'] > vec_len:
                vec.extend([0]*(self.settings['doc_size']-vec_len))

            # clipping: 原本就超過最大長度的話就切掉
            else:
                vec = vec[:self.settings['doc_size']]

        elif self.cnn_version == "text_cnn":
            if not self.tokenizer or not self.w2v_model:
                raise ValueError("plz enable_word_embedding before training...")

            # Word Embedding
            tokens = [term["word"] for term in self.tokenizer.standard_tokenizer(sent)]
            for token in tokens:
                if token in self.index2word_set:
                    vec.append(self.w2v_model[token])

            # padding: 補上零的字向量讓矩陣長度固定
            vec_len = len(vec)
            for i in range(vec_len, self.settings['doc_size']):
                vec.append(np.zeros([self.settings['embed_dimension']]))
            # clipping: 原本就超過最大長度的話就切掉
            vec = vec[:self.settings['doc_size']]

        elif self.cnn_version == "text_cnn_en":
            if not self.tokenizer or not self.w2v_model:
                raise ValueError("plz enable_word_embedding before training...")

            # Word Embedding
            tokens = [term for term in sent.split()]

            # Filter stopwords

            for token in tokens:
                if token in self.index2word_set:
                    vec.append(self.w2v_model[token])

            # padding: 補上零的字向量讓矩陣長度固定
            vec_len = len(vec)
            for i in range(vec_len, self.settings['doc_size']):
                vec.append(np.zeros([self.settings['embed_dimension']]))
            # clipping: 原本就超過最大長度的話就切掉
            vec = vec[:self.settings['doc_size']]

        elif self.cnn_version == "bert_embed_cnn" or self.cnn_version == "bert_classifier":
            if not self.bert_tokenizer or not self.bert_model:
                raise ValueError("plz enable_bert before training...")

            # tokenizer = BertTokenizer.from_pretrained(chinese_bert_model_path)
            tokenized_text = ["[CLS]"]
            tokenized_text.extend(self.bert_tokenizer.tokenize(sent))
            tokenized_text.append("[SEP]")
            indexed_tokens = self.bert_tokenizer.convert_tokens_to_ids(tokenized_text)

            # segments_ids = np.zeros(len(indexed_tokens))
            # tokens_tensor = torch.Tensor([indexed_tokens])
            # segments_tensors = torch.LongTensor([segments_ids])

            vec = indexed_tokens
            # padding: 補上零的字向量讓矩陣長度固定
            vec_len = len(vec)
            if self.settings['doc_size'] > vec_len:
                vec.extend([0]*(self.settings['doc_size']-vec_len))

            # clipping: 原本就超過最大長度的話就切掉
            else:
                vec = vec[:self.settings['doc_size']]
        else:
            raise ValueError("CNN version Error!: {}".format(self.cnn_version))
        return vec

    def get_settings(self):
        return self.settings

    # Can only be used after intent lookup was built
    def get_target(self, idx):
        try:
            return self.target_lookup[idx]
        except:
            logger.error("intent_lookup was not built yet")

    # def _get_train_data(self):
    #     idx_from = 0
    #     idx_to = len(self.features)
    #     return self.features[idx_from:idx_to], self.target[idx_from:idx_to]

    def get_dataset(self):
        # features, target = self._get_train_data()
        # idx_to = len(self.features)
        features = self.features[:self.to_train]
        target = self.target[:self.to_train]
        return ClassifyDataset(features, target, char_level=self.char_level)

    def get_validation_dataset(self):
        features = self.features[self.to_train:]
        target = self.target[self.to_train:]
        return ClassifyDataset(features, target, char_level=self.char_level)

    def custom_dataset(self, from_idx, to_idx):
        features = self.features[from_idx:to_idx]
        target = self.target[from_idx:to_idx]
        return ClassifyDataset(features, target, char_level=self.char_level)

