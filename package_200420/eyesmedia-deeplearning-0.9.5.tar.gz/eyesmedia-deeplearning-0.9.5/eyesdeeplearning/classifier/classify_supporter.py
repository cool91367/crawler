# -*- coding: utf-8 -*-
import logging
import traceback
import numpy as np
import time
import torch
import torch.nn.functional as F
import torch.multiprocessing as mp
from torch.nn import DataParallel
from tqdm import tqdm
from eyesdeeplearning.supporter.generic import TorchModelGenericSupporter, set_torch_manual_seed
from eyesdeeplearning.classifier.model.text_cnn import TextCNN
from eyesdeeplearning.classifier.model.char_cnn import CharCNN
from eyesdeeplearning.classifier.model.char_cnn_conv2 import CharCNNConv2
from eyesdeeplearning.classifier.model.naive_nn import NaiveNN
from sklearn.decomposition import IncrementalPCA
from sklearn.manifold import TSNE
import gc

logger = logging.getLogger("eyesdeeplearning")


class ClassifySupporter(TorchModelGenericSupporter):

    def __init__(self, nn_params, data_provider):
        nn_params = self._check_nn_params(nn_params)
        self.data_provider = data_provider

        self.device, self.device_name, self.n_gpu = self._check_device(nn_params['no_cuda'])
        nn_params['device'] = self.device

        super().__init__(nn_params)

        if not nn_params['no_cuda']:
            self._check_parallel(no_parallel=False)  # 宣告完model才能用

    def _check_nn_params(self, nn_params):
        if 'scatter' not in nn_params:
            logger.warning('version 0.9.4: scatter parameter should be set')
            logger.warning('set as default value: 2D')
            nn_params['scatter'] = '2D'
        else:
            if nn_params['scatter'] not in ['2D', '3D']:
                logger.warning('version 0.9.4: scatter parameter should be set as 2D or 3D')
                logger.warning('set as default value: 2D')
                nn_params['scatter'] = '2D'
        if 'no_cuda' not in nn_params:
            logger.warning('version 0.9.3: no_cuda parameter should be set')
            nn_params['no_cuda'] = False

        if 'parallel' not in nn_params:
            logger.warning('version 0.9.3: parallel parameter should be set')
            nn_params['parallel'] = True
        return nn_params

    def _check_device(self, no_cuda=False):
        # cuda 0.9.3
        # Checking device cpu or gpu
        device = torch.device("cuda" if torch.cuda.is_available() and not no_cuda else "cpu")
        device_name = str(device)
        if device_name == "cuda":
            n_gpu = torch.cuda.device_count()
            # if n_gpu > 0:
            #     torch.cuda.manual_seed_all(1)
            logger.info("torch version is {}, device is {}, GPU count is {}. threads num is {}, nn_model move to {}".format(
                torch.__version__, device, n_gpu, torch.get_num_threads(), device)
            )
        else:
            n_gpu = 0
        return device, device_name, n_gpu

    def _check_parallel(self, no_parallel=False):
        if self.n_gpu > 1 and not no_parallel:
            logger.info("Parallel GPUs number: {}".format(self.n_gpu))
            self.nn_model = DataParallel(self.nn_model, device_ids=list(range(self.n_gpu)), dim=0)

    def _init_nn_model(self):

        # setting version
        cnn_version = self.nn_params["cnn-version"]
        available_versions = ['text_cnn', 'text_cnn_en', 'char_cnn', 'char_cnn_conv2', 'bert_embed_cnn', 'bert_classifier']

        # Fixed Params
        self.nn_params["embed-dimension"] = self.data_provider.get_settings()['embed_dimension']
        logger.info("embed-dimension was auto-detected as {}".format(self.nn_params["embed-dimension"]))
        self.nn_params["shuffle"] = True

        # Check! parameter: class-number should be larger then data class-number
        # If smaller, will waste memory, but not causing error
        num_cls = len(self.data_provider.target_lookup)
        if self.nn_params["class-number"] < num_cls:
            logger.warning("nn_params class-number: {}, but got {} classes from data".format(self.nn_params["class-number"], num_cls))
            logger.warning("reset nn_params class-number: {}".format(num_cls))
            self.nn_params["class-number"] = num_cls

        # Text CNN
        if cnn_version == "text_cnn":
            if self.data_provider.char_level:
                logger.error("Using {} while char_level is True!?".format(cnn_version))
            self.nn_model_name = "TextCNN"
            return TextCNN(self.nn_params).to(self.device)

        # Text CNN en version
        elif cnn_version == "text_cnn_en":
            if self.data_provider.char_level:
                logger.error("Using {} while char_level is True!?".format(cnn_version))
            self.nn_model_name = "TextCNN"
            return TextCNN(self.nn_params).to(self.device)

        # Char CNN with 1 convolution Layer
        elif cnn_version == "char_cnn":
            if not self.data_provider.char_level:
                logger.error("Using {} while char_level is False!?".format(cnn_version))
            self.nn_params["embed-num"] = len(self.data_provider.char_dict)
            self.nn_model_name = "CharCNN"
            return CharCNN(self.nn_params).to(self.device)

        # Char CNN with 2 convolution layer
        elif cnn_version == "char_cnn_conv2":
            if not self.data_provider.char_level:
                logger.error("Using {} while char_level is False!?".format(cnn_version))
            self.nn_params["embed-num"] = len(self.data_provider.char_dict)
            self.nn_model_name = "CharCNNConv2"
            return CharCNNConv2(self.nn_params).to(self.device)

        # bert_classifier
        elif cnn_version == "bert_classifier":
            self.nn_model_name = "NaiveNN"
            self.bert_model = self.data_provider.bert_model
            if not self.bert_model:
                raise ValueError('BERT model is None!')
            self.bert_model.to(self.device)
            return NaiveNN(self.nn_params).to(self.device)

        # Bert Embed CNN
        elif cnn_version == "bert_embed_cnn":
            self.nn_model_name = "TextCNN"
            self.bert_model = self.data_provider.bert_model
            if not self.bert_model:
                raise ValueError('BERT model is None!')
            self.bert_model.to(self.device)
            return TextCNN(self.nn_params).to(self.device)
        else:
            logger.error("Please specify cnn version from {0}".format(available_versions))

    def _extract_features(self, feature, mode):
        if mode == 'logit':
            # size estimation
            # batch_size x class_number
            cnn_features = self.nn_model(feature)
            cnn_features = cnn_features.detach().numpy()
        elif mode == 'cnn_features':
            # batch_size x 1600
            cnn_features = self.nn_model.cnn_features(feature)
            cnn_features = cnn_features.detach().numpy()
        else:
            # mode == 'embedding'
            # batch_size x 256 x 30
            cnn_features = self.nn_model.embedding(feature)
            cnn_features = cnn_features.detach().numpy()
        return cnn_features

    def train_tsne_model(self, mode='logit'):
        if self.nn_params['scatter'] == '3D':
            tsne_model = TSNE(n_components=3)
        elif self.nn_params['scatter'] == '2D':
            tsne_model = TSNE(n_components=2)
        else:
            raise ValueError("scatter parameters is not set correctly")

        if mode not in ['logit', 'cnn_features', 'embedding']:
            raise ValueError('Please select a mode in [logit, cnn_features, embedding]')
        if self.nn_params['cnn-version'] != 'char_cnn':
            raise ValueError('version 0.9.3 only support char_cnn to train tsne model')
        if self.data_provider.size > 10000:
            logger.info("Dataset too big! We only choose 10000 samples to plot.")
            dataset = self.data_provider.custom_dataset(0, 10000)
        else:
            logger.info("Put {} samples into PCA".format(self.data_provider.size))
            dataset = self.data_provider.get_dataset()
        data_loader = torch.utils.data.DataLoader(dataset,
                                                  batch_size=self.nn_params["batch-size"],
                                                  shuffle=self.nn_params["shuffle"],
                                                  num_workers=self.nn_params["num-workers"],
                                                  drop_last=True
                                                  )

        pca_dec_number = 10 if self.nn_params['class-number'] > 10 else self.nn_params['class-number']
        sub_pca_model = IncrementalPCA(n_components=pca_dec_number,
                                            batch_size=self.nn_params['batch-size'])

        mapped_list = []
        target_list = []
        for feature, target in data_loader:
            cnn_features = self._extract_features(feature, mode)
            _pca = sub_pca_model.partial_fit(cnn_features)  # train pca model
            mapped_vector = sub_pca_model.transform(cnn_features)
            mapped_list.append(mapped_vector)
            target_list.extend(list(target.numpy()))
        variance_ratio = sub_pca_model.explained_variance_ratio_
        stack_variance_ratio = np.cumsum(variance_ratio)
        logger.info("Variance is {} after PCA Decomposition from {} dim to {} dim".format(
            stack_variance_ratio[pca_dec_number - 1], self.nn_params['class-number'], pca_dec_number))
        if stack_variance_ratio[pca_dec_number - 1] > 0.8:
            logger.info("Nice! Variance is high enough to present!")
        else:
            logger.info("Oops! Variance is too low!")

        mapped_vectors = np.concatenate(mapped_list, axis=0)
        mapped_vectors = tsne_model.fit_transform(mapped_vectors)

        # release memory
        del tsne_model
        del sub_pca_model
        gc.collect()

        return mapped_vectors, target_list

    def train_pca_model(self, mode='logit'):
        # self._init_pca_model()
        if self.nn_params['scatter'] == '3D':
            pca_model = IncrementalPCA(n_components=3, batch_size=self.nn_params['batch-size'])
        elif self.nn_params['scatter'] == '2D':
            pca_model = IncrementalPCA(n_components=2, batch_size=self.nn_params['batch-size'])
        else:
            raise ValueError("scatter parameters is not set correctly")

        if mode not in ['logit', 'cnn_features', 'embedding']:
            raise ValueError('Please select a mode in [logit, cnn_features, embedding]')
        if self.nn_params['cnn-version'] != 'char_cnn':
            raise ValueError('version 0.9.3 only support char_cnn to train pca model')
        dataset = self.data_provider.get_dataset()
        data_loader = torch.utils.data.DataLoader(dataset,
                                                  batch_size=self.nn_params["batch-size"],
                                                  shuffle=self.nn_params["shuffle"],
                                                  num_workers=self.nn_params["num-workers"],
                                                  drop_last=True
                                                  )
        mapped_list = []
        target_list = []
        for feature, target in data_loader:
            cnn_features = self._extract_features(feature, mode)
            pca_model = pca_model.partial_fit(cnn_features)  # train pca model
            mapped_vector = pca_model.transform(cnn_features)
            mapped_list.append(mapped_vector)
            target_list.extend(target)

        mapped_vectors = np.concatenate(mapped_list, axis=0)

        # print variance ratio
        variance_ratio = pca_model.explained_variance_ratio_

        # release memory
        del pca_model
        gc.collect()

        # return all transformed vectors
        return variance_ratio, mapped_vectors, target_list

    def predict(self, text, *args, **kwargs):
        # @params
        # text: str
        #
        # @keyword params
        # top: int
        #       return topk result back
        # form: value in ["multi-class", "multi-label"]
        #       Get Probabilities under what kind of premise

        # Top k
        topk = kwargs.get("top", 1)
        if self.nn_params["class-number"] < topk:
            topk = self.nn_params["class-number"]

        # Multi-label or Multi-class Classification
        # == dev 0.9.3 ===
        form = kwargs.get("form", "multi-class")
        if form not in ["multi-class", "multi-label"]:
            logging.error("keyword parameter 'form' should be either multi-class or multi-label while {}".format(form))

        # Pre-process input string
        vec = self.data_provider.feature2vec(text)
        if not self.data_provider.char_level:
            vec = torch.Tensor(vec)
        else:
            vec = torch.LongTensor(vec)

        # Moving to CPU or GPU if needed
        vec = vec.to(self.device)

        # Dimension Adaption
        vec = torch.unsqueeze(vec, 0)  # (1, doc_dim)

        # BERT Layer
        if self.nn_params['cnn-version'] in ['bert_embed_cnn', 'bert_classifier']:
            vec = self.bert_embed(vec, self.nn_params['cnn-version'])

        # Random Seed and Fit into Model
        set_torch_manual_seed()
        pre_data = self.nn_model(vec)

        scores, preds = torch.topk(pre_data, k=self.nn_params["class-number"], dim=1)
        scores, preds = scores.cpu(), preds.cpu()
        pred_scores = scores[0].detach().numpy()

        # Output Layer
        if form == "multi-class":
            # Use Softmax for multi-class classification
            pred_scores = np.exp(pred_scores) / np.sum(np.exp(pred_scores))
        else:
            # Use Sigmoid for multi-label classification
            pred_scores = 1 / (1 + np.exp(-1 * pred_scores))

        # Return top k
        pred_intent = []
        for i in range(topk):
            pred_intent.append(self.data_provider.get_target(preds[0][i]))
        return pred_intent, pred_scores[:topk]

    def bert_embed(self, feature, cnn_version):
        segments_ids = np.zeros(list(feature.shape))
        segments_tensors = torch.LongTensor(segments_ids)
        segments_tensors = segments_tensors.to(self.device)
        encoded_layers, _ = self.bert_model(feature, segments_tensors)
        # 32, 30. 768
        self.bert_model.eval()
        with torch.no_grad():
            encoded_layers, _ = self.bert_model(feature, segments_tensors)
        if cnn_version == 'bert_classifier':
            indices = torch.LongTensor([0]).to(self.device)
            feature = torch.index_select(encoded_layers[-1], 1, indices)
        elif cnn_version == 'bert_embed_cnn':
            feature = encoded_layers[-1]
        return feature

    def _train(self, nn_model, data_loader, process_id, callback=None):
        set_torch_manual_seed()
        if process_id == -1:
            logger.info("[Single] - Start train model({}), params: {}".format(self.nn_model_name, self.nn_params))
        else:
            logger.info("[Parallel] Process[{}] - Start train model(), params: {}".format(set_torch_manual_seed, self.nn_model_name, self.nn_params))

        validation_data_loader = None
        if process_id == -1:
            logger.info("[Single] - Use Validation Dataset")
            validation_dataset = self.data_provider.get_validation_dataset()
            validation_data_loader = torch.utils.data.DataLoader(validation_dataset,
                                                                 batch_size=self.nn_params["batch-size"],
                                                                 shuffle=self.nn_params["shuffle"],
                                                                 num_workers=self.nn_params["num-workers"],
                                                                 drop_last=self.nn_params["drop-last"]
                                                                 )

        numOfepoch = self.nn_params["epoch"]
        optimizer = torch.optim.Adam(nn_model.parameters(), lr=self.nn_params["learning-rate"])

        quarter = int(len(data_loader) / 4)
        if quarter == 0:
            quarter = 1

        best_accuracy = -1
        for epoch in range(numOfepoch):
            step = 1
            total_loss = 0
            # Read Data per batch
            start_time = time.time()
            for feature, target in data_loader:
                try:
                    # in pytorch 0.4.1 Tensor == Variable
                    # features, target = Variable(features), Variable(target)
                    feature, target = feature.to(self.device), target.to(self.device)

                    # Bert Embedded
                    if self.nn_params['cnn-version'] in ['bert_embed_cnn', 'bert_classifier']:
                        feature = self.bert_embed(feature, self.nn_params['cnn-version'])

                    # Run Model
                    optimizer.zero_grad()
                    label = nn_model(feature)

                    loss = F.cross_entropy(label, target)
                    loss.backward()
                    optimizer.step()

                    total_loss += loss.item()
                    if step % quarter == 0 or step == len(data_loader):
                        # corrects = (torch.max(label, 1)[1].view(target.size()).data == target.data).sum()
                        corrects = torch.sum(torch.max(label, 1)[1] == target).item()
                        accuracy = corrects / data_loader.batch_size
                        if process_id == -1:
                            logger.info(
                                "[Single] - Epoch[{}] Batch[{}/{}] >>> Loss={:.5f} Acc={:.5f}({}/{})".format(
                                    epoch + 1, step, len(data_loader), loss.item(), accuracy, corrects,
                                    data_loader.batch_size))
                        else:
                            logger.info(
                                "[Parallel] Process[{}] - Epoch[{}] Batch[{}/{}] >>> Loss={:.5f} Acc={:.5f}({}/{})".format(
                                process_id, epoch + 1, step, len(data_loader), loss.item(), accuracy, corrects,
                                data_loader.batch_size))
                    step += 1
                except MemoryError:
                    logger.error("Memory is not enough! Try lower batch size, current is {}".format(self.nn_params["batch-size"]))
                    raise
            if process_id == -1:
                # Non-parallel: Run Call back
                # Evaluation
                save_flag = False
                total_accuracy = 0
                if validation_data_loader:
                    total_accuracy = self.evaluate(validation_data_loader)
                    if total_accuracy > best_accuracy:
                        save_flag = True
                        best_accuracy = total_accuracy
                        logger.info("[Single] - Best Acc {:.5f} at Preset: Epoch({}/{})".format(
                                best_accuracy, epoch + 1, numOfepoch))
                else:
                    # raise ValueError
                    save_flag = True
                    logger.warning("[Single] - Validation Dataloader is None... Fail to evaluate...")

                avg_loss = total_loss / len(data_loader) if total_loss > 0 else 0
                cost_time = round(time.time() - start_time)
                if save_flag:  # total_accuracy > best_accuracy:
                    # best_accuracy = total_accuracy
                    # logger.info('epoch({}/{}) has best accuracy:{}'.format(epoch + 1, numOfepoch, best_accuracy))
                    if self.nn_params.get("model_file"):
                        try:
                            self.save_model(self.nn_params["model_file"])
                            logger.info("[Single] - Successfully Save Model that has best Acc {:.5f} at present".format(best_accuracy))
                        except:
                            logger.warning("[Single] - Epoch({}/{}) Best Acc at present but fail to save model...".format(
                                epoch + 1, numOfepoch
                            ))
                    else:
                        logger.warning("[Single] - Parameter 'model_file' is not defined. No models are saved.")

                if callback and callable(callback):
                    try:
                        callback(epoch + 1, numOfepoch, cost_time, total_accuracy)
                    except:
                        logger.warning("[Single] - Epoch({}/{}) callback function error...".format(epoch + 1, numOfepoch))

                logger.info("[Single] - Epoch({}/{}) >>> Time={} Avg Loss={:.5f} Acc={:.5f} Best Acc={:.5f}".format(
                    epoch + 1, numOfepoch, cost_time, avg_loss, total_accuracy, best_accuracy)
                )

        if process_id != -1:
            logger.info("[Parallel] Process[{}] - Delete Copied model".format(process_id))
            del nn_model

    def train_model(self, callback=None):
        if self.nn_params['parallel']:
            cores = mp.cpu_count()
            slices = int(self.data_provider.size / cores)
            data_loaders = []
            for i in range(cores):
                slice_dataset = self.data_provider.custom_dataset(i * slices, (i + 1) * slices)
                data_loader = torch.utils.data.DataLoader(slice_dataset,
                                                          batch_size=self.nn_params["batch-size"],
                                                          shuffle=self.nn_params["shuffle"],
                                                          num_workers=self.nn_params["num-workers"],
                                                          drop_last=self.nn_params["drop-last"]
                                                          )
                data_loaders.append(data_loader)
            model = self.nn_model.share_memory()
            processes = []
            logger.info("Paralleling into {} processes".format(cores))
            for rank in range(cores):
                p = mp.Process(target=self._train, args=(model, data_loaders[rank], rank))
                p.start()
                processes.append(p)
            for p in processes:
                p.join()
            logger.info("<<< Parallel processes {} end, save models".format(cores))
            if self.nn_params.get("model_file"):
                try:
                    self.save_model(self.nn_params["model_file"])
                except:
                    logger.error(traceback.format_exc())
            else:
                logger.warning("[Parallel] - Parameter 'model_file' is not defined. No models are saved.")

        else:
            dataset = self.data_provider.get_dataset()
            data_loader = torch.utils.data.DataLoader(dataset,
                                                      batch_size=self.nn_params["batch-size"],
                                                      shuffle=self.nn_params["shuffle"],
                                                      num_workers=self.nn_params["num-workers"],
                                                      drop_last=self.nn_params["drop-last"]
                                                      )
            self._train(self.nn_model, data_loader, -1, callback)

    def evaluate(self, dataset_loader):
        logger.info("Validation Dataset Size: {}".format(len(dataset_loader.dataset)))
        self.nn_model.eval()
        corrects = 0
        eval_step = 1
        eval_quarter = int(len(dataset_loader) / 4)
        if eval_quarter == 0:
            eval_quarter = 1

        for feature, target in dataset_loader:
            feature, target = feature.to(self.device), target.to(self.device)
            if self.nn_params['cnn-version'] in ['bert_embed_cnn', 'bert_classifier']:
                feature = self.bert_embed(feature, self.nn_params['cnn-version'])
            output = self.nn_model(feature)
            _, pred = torch.max(output, 1)
            # corrects += (pred.view(target.size()).data == target.data).sum()
            corrects += torch.sum(pred == target).item()
            if eval_step % eval_quarter == 0 or eval_step == len(dataset_loader):
                logger.info("Evaluate Process - Batch [{}/{}] finished".format(eval_step, len(dataset_loader)))
            eval_step += 1

        size = len(dataset_loader.dataset)
        accuracy = corrects / size
        logger.info('Validation Accuracy:{:.5f} Correct={} Total={}'.format(accuracy, corrects, size))
        return accuracy

    def test_model(self, test_data_provider):
        logger.info("loading testing dataset from DataLoader...")
        dataset = test_data_provider.get_dataset()
        dataset_loader = torch.utils.data.DataLoader(dataset,
                                                     # batch_size=64,
                                                     batch_size=self.nn_params["batch-size"],
                                                     shuffle=self.nn_params["shuffle"],
                                                     num_workers=self.nn_params["num-workers"]
                                                     )

        result = []
        hit = 0
        total = 0
        logger.info("Running testing...")
        for features, target in dataset_loader:
            features, target = features.to(self.device), target.to(self.device)
            if self.nn_params['cnn-version'] in ['bert_embed_cnn', 'bert_classifier']:
                features = self.bert_embed(features, self.nn_params['cnn-version'])
            # run model
            output = self.nn_model(features)
            _, predicted = torch.max(output, 1)
            for idx, pred in enumerate(predicted):
                result.append((pred, target[idx]))
                if pred == target[idx]:
                    hit += 1
            total += len(predicted)
        total_accuracy = hit / total
        logger.info("Test Accuracy:{:.5f}".format(total_accuracy))
        return self._eval_scores(result, self.data_provider.target_lookup)

    def _eval_scores(self, result, target_lookup):
        num_of_class = len(target_lookup)

        recall = np.zeros([num_of_class])
        precision = np.zeros([num_of_class])
        accuracy = np.zeros([num_of_class])
        count = np.zeros([num_of_class])

        for cls in range(0, num_of_class):
            tn = 0
            tp = 0
            fn = 0
            fp = 0
            cnt = 0
            for res in result:
                pred = res[0]
                cond = res[1]
                pred = 1 if pred == cls else 0
                cond = 1 if cond == cls else 0
                if pred == cond == 1:
                    tp += 1
                elif pred == cond == 0:
                    tn += 1
                else:
                    if pred == 1 and cond == 0:
                        fp += 1
                    else:
                        fn += 1
                cnt += cond
            count[cls] = cnt
            recall[cls] = (tp + 0.000001) / (tp + fn + 0.0001)
            precision[cls] = (tp + 0.000001) / (tp + fp + 0.0001)
            accuracy[cls] = (tp + tn) / (tp + tn + fp + fn)  # No use, since tn are too large
            logger.debug("cls: {}. tp: {}, tn: {}, fp:{}, fn:{}".format(target_lookup[cls], tp, tn, fp, fn))
        fscore = ((2 * recall * precision) + 0.000001) / (recall + precision + 0.0001)

        logger.debug("Emotion: {}".format(target_lookup))
        logger.debug("recall:{}".format(recall))
        logger.debug("precision:{}".format(precision))
        logger.debug("F-score:{}".format(fscore))
        logger.info("mean recall:{:.5f}".format(np.mean(recall)))
        logger.info("mean precision:{:.5f}".format(np.mean(precision)))
        logger.info("mean F-score:{:.5f}".format(np.mean(fscore)))

        w = []
        for cls in range(0, num_of_class):
            w.append((target_lookup[cls], count[cls], fscore[cls], recall[cls], precision[cls]))
        w.sort()
        return w
