# -*- coding: utf-8 -*-
import logging
import abc
import os
import random
import numpy as np
import torch

logger = logging.getLogger("eyesdeeplearning")


def set_torch_manual_seed(seed=1):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    n_gpu = torch.cuda.device_count()
    if n_gpu > 0:
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


class TorchModelGenericSupporter(abc.ABC):

    def __init__(self, nn_params):
        self.nn_params = nn_params
        self.nn_model = self._init_nn_model()

    def load_model(self, file, num_threads=0):
        """
        :param file:
        :param num_threads: set 1 when run with multiprocessing (using fork). see https://github.com/pytorch/pytorch/issues/17199#issuecomment-465313245
        :return:
        """
        if num_threads > 0:
            max_num_threads = torch.get_num_threads()
            if num_threads > max_num_threads:
                logger.warning("threads({}) more than the max threads({}), change to {}".format(num_threads, max_num_threads, max_num_threads))
                torch.set_num_threads(max_num_threads)
            else:
                torch.set_num_threads(num_threads)

        if torch.cuda.is_available() and not self.nn_params["no_cuda"]:
            model_state = torch.load(file)
        else:
            model_state = torch.load(file, map_location='cpu')

        self.nn_model.load_state_dict(model_state["state"], strict=False)
        logger.info("load model from {} finish...".format(file))

    def save_model(self, file):
        n_gpu = torch.cuda.device_count()
        if n_gpu > 1:
            model_state = {
                "state": self.nn_model.module.state_dict()
            }
        else:
            model_state = {
                "state": self.nn_model.state_dict()
            }
        torch.save(model_state, file)
        logger.info("save nn model to {}".format(file))

    @abc.abstractmethod
    def _init_nn_model(self):
        pass

    @abc.abstractmethod
    def train_model(self, callback=None):
        pass

    @abc.abstractmethod
    def predict(self, text, *args, **kwargs):
        pass
