# -*- coding: utf-8 -*-
import logging
import os
import torch
import torch.optim as optim
from eyesdeeplearning.supporter.generic import TorchModelGenericSupporter
from eyesdeeplearning.model.ner import BiLSTM_CRF

logger = logging.getLogger("eyesdeeplearning")


class TBiLSTM_CRFSupporter(TorchModelGenericSupporter):
    # nn_params = {
    #     "embedding_size": 100,
    #     "hidden_size": 128,
    #     "batch_size": 16,
    #     "dropout": 0.5,
    #     "epoch": 100
    # }

    def __init__(self, nn_params, data_provider):
        self.ner_data_provider = data_provider
        self.vocab = self.ner_data_provider.vocab
        self.tag_map = self.ner_data_provider.tag_map
        super().__init__(nn_params)

    def _init_nn_model(self):
        return BiLSTM_CRF(
            tag_map=self.tag_map,
            batch_size=self.ner_data_provider.batch_size,
            vocab_size=len(self.vocab),
            dropout=self.nn_params["dropout"],
            embedding_dim=self.nn_params["embedding_size"],
            hidden_dim=self.nn_params["hidden_size"]
        )

    def load_model(self, file):
        self.nn_model.load_state_dict(torch.load(file))
        logger.info("load model from {} finish...".format(file))

    def train_model(self, callback=None):
        logger.info("train model start, config is {}".format(self.nn_params))
        optimizer = optim.Adam(self.nn_model.parameters(), lr=0.01)
        # optimizer = optim.SGD(ner_model.parameters(), lr=0.01)

        best_loss = None
        total_batch_data = len(self.ner_data_provider.batch_data)
        for epoch in range(self.nn_params["epoch"]):
            logger.info("===== Start training on epoch {} =====".format(epoch))
            index = 0
            for batch in self.ner_data_provider.get_batch():
                index += 1
                self.nn_model.zero_grad()
                sentences, tags, length = zip(*batch)
                sentences_tensor = torch.tensor(sentences, dtype=torch.long)  # one-hot for each sentence in batch.
                tags_tensor = torch.tensor(tags, dtype=torch.long)  # one-hot for each tag in batch.
                length_tensor = torch.tensor(length, dtype=torch.long)  # real length for each unpadded sentence in batch.

                loss = self.nn_model.neg_log_likelihood(sentences_tensor, tags_tensor, length_tensor)
                loss_value = loss.cpu().tolist()[0]
                loss.backward()
                optimizer.step()

                if index % 10 == 0:
                    logger.info("Iterating epoch:{} (excute batch index:{}/{}), Loss:{}".format(epoch, index, total_batch_data, loss_value))

                if not best_loss or loss_value < best_loss:
                    best_loss = loss_value
                    torch.save(self.nn_model.state_dict(), self.nn_params["model_file"])
                    logger.info(">> model has been saved as {}. (best loss:{})".format(self.nn_params["model_file"], best_loss))
                    # self.evaluate()
        logger.info("train model finished, best loss:{}".format(best_loss))

    def test_model(self, data_provider):
        logger.info("loading testing dataset from DataLoader...")

    def predict(self, text, *args, **kwargs):
        input_vec = [self.vocab.get(i, 0) for i in text]
        sentences = torch.tensor(input_vec).view(1, -1)
        pre_data = self.nn_model.predict(sentences)
        if not pre_data:
            logger.warning("input:{} >>> no predict data".format(text))
            return None

        pre_data = max(pre_data)
        tagid_map = dict((v, k) for k, v in self.tag_map.items())
        # tagids = pre_data[1]
        tags = [tagid_map[t] for t in pre_data[1]]
        # logger.info("{} >>> predict ner tag:{}".format(text, tags))
        words = self.__tag2words(text, tags)
        # logger.warning("input:{} >>> predict ner words is {}".format(text, words))
        return words

    def __tag2words(self, text, predict_tags):
        offset = 0
        jump_flag = -1
        tags_len = len(predict_tags)
        words = []
        for word, tag in zip(text, predict_tags):
            if offset < jump_flag:
                offset += 1
                continue

            prefix = tag[0]
            if prefix != "B":
                offset += 1
                continue

            if prefix == "B":
                labels = tag.split("-")
                labels = labels[1] if len(labels) > 0 else labels
                if offset + 1 >= tags_len:  # 代表最後一個，不用再去找剩下的tag
                    words.append((text[offset:], labels, [offset, offset]))
                    break

                w_idx_s = offset
                end_prefix = "E" + tag[1:]
                end_prefix_idx = 0
                for i, t in enumerate(predict_tags[offset:]):
                    if t == end_prefix:
                        end_prefix_idx = i
                        break
                w_idx_e = w_idx_s + end_prefix_idx
                jump_flag = w_idx_e + 1
                offset += 1
                words.append((text[w_idx_s:w_idx_e + 1], labels, [w_idx_s, w_idx_e]))
        return words
