# -*- coding: utf-8 -*-
import logging
import numpy as np
import time
import torch
import torch.nn.functional as F
from torch.autograd import Variable
from eyesdeeplearning.supporter.generic import TorchModelGenericSupporter
from eyesdeeplearning.model.text_cnn import TextCNN

logger = logging.getLogger("eyesdeeplearning")


class TextCNNSupporter(TorchModelGenericSupporter):

    def __init__(self, nn_params, data_provider):
        super().__init__(nn_params)
        self.data_provider = data_provider
        self.char_level = data_provider.char_level

    def _init_nn_model(self):
        return TextCNN(self.nn_params)

    def train_model(self, callback=None):

        device = torch.device("cuda" if torch.cuda.is_available() and self.nn_params["no_cuda"] else "cpu")
        n_gpu = torch.cuda.device_count()
        torch.manual_seed(self.nn_params["manual_seed"])
        if n_gpu > 0:
            torch.cuda.manual_seed_all(self.nn_params["manual_seed"])

        # logger.info("torch before set threads num is {}".format(torch.get_num_threads()))
        # torch.set_num_threads(1)
        logger.info("torch version is {}, device is {}, GPU count is {}. threads num is {}, nn_model move to {}".format(
            torch.__version__, device, n_gpu, torch.get_num_threads(), device)
        )

        logger.info("loading dataset from DataLoader...")
        dataset = self.data_provider.get_generic_dataset()
        data_loader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True, num_workers=4)

        self.nn_model.to(device)

        logger.info("start training, params:{}".format(self.nn_params))
        total_epoch = self.nn_params["epoch"]
        optimizer = torch.optim.Adam(self.nn_model.parameters(), lr=self.nn_params["learning-rate"])

        best_accuracy = 0
        for epoch in range(0, total_epoch):
            step = 1
            total_loss = 0
            start_time = time.time()
            # Read Data per batch
            for features, label in data_loader:
                # features, label = Variable(features), Variable(label)
                features, label = features.to(device), label.to(device)

                # Run Model
                optimizer.zero_grad()
                emotion_label = self.nn_model(features)

                loss = F.cross_entropy(emotion_label, label)
                loss.backward()
                optimizer.step()

                loss_value = loss.item()  # loss.data[0]
                total_loss += loss_value
                if step % 100 == 0:
                    logger.info("epoch({}/{}) run step({}/{}), loss:{}".format(epoch + 1, total_epoch, step, len(data_loader), loss_value))
                    # corrects = torch.sum(torch.max(label, 1)[1] == label).item()
                    # accuracy = corrects / data_loader.batch_size
                    # logger.info("epoch[{}]:batch[{}/{}] >>> loss:{}, acc:{}({}/{})".format(
                    #     epoch + 1, step, len(data_loader), loss.item(), accuracy, corrects, data_loader.batch_size)
                    # )
                step += 1

            # Evaluation
            total_accuracy = self.evaluate(data_loader, device)
            avg_loss = total_loss / len(data_loader)
            if total_accuracy > best_accuracy:
                best_accuracy = total_accuracy
                logger.info('epoch({}/{}) has best accuracy:{}'.format(epoch + 1, total_epoch, best_accuracy))
                if self.nn_params.get("model_file"):
                    try:
                        self.save_model(self.nn_params["model_file"])
                    except:
                        logger.warning(
                            "epoch({}/{}) has best accuracy:{} but save model failure...".format(epoch + 1, total_epoch,
                                                                                                 best_accuracy))

                cost_time = round(time.time() - start_time)
                logger.info('finish epoch({}/{}) cost time:{}, avg loss:{}, best accuracy:{}'.format(
                    epoch + 1, total_epoch, cost_time, avg_loss, best_accuracy)
                )

                if callback and callable(callback):
                    try:
                        callback(epoch + 1, total_epoch, cost_time, best_accuracy)
                    except:
                        logger.warning("epoch({}/{}) call back function has error..".format(epoch + 1, total_epoch))

            logger.info('epoch[{}/{}]: avg loss:{}, accuracy:{}, best_accuracy:{}'.format(epoch + 1, total_epoch, avg_loss, total_accuracy, best_accuracy))
        logger.info("train model finish...")

    def evaluate(self, dataset_loader, device):
        self.nn_model.eval()
        corrects, avg_loss = 0, 0
        for feature, target in dataset_loader:
            feature, target = feature.to(device), target.to(device)
            output = self.nn_model(feature)
            _, pred = torch.max(output, 1)
            # corrects += (pred.view(target.size()).data == target.data).sum()
            corrects += torch.sum(pred == target).item()

        size = len(dataset_loader.dataset)
        accuracy = corrects / size
        logger.info('Evaluation - acc:{}({}/{})'.format(accuracy, corrects, size))
        return accuracy

    def test_model(self, test_data_provider):
        logger.info("loading testing dataset from DataLoader...")
        dataset = test_data_provider.get_generic_dataset()
        dataset_loader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True, num_workers=4)

        logging.info("running testing...")
        hit = 0
        total = 0
        result = []
        for features, label in dataset_loader:
            # Run Model
            output = self.nn_model(features)
            _, predicted = torch.max(output, 1)
            for idx, pred in enumerate(predicted):
                result.append((pred, label[idx]))
                if pred == label[idx]:
                    hit += 1
                # logger.info("pred:{}, label[{}]:{}".format(pred, idx, label[idx]))
            total += len(predicted)

        total_accuracy = hit / total
        logger.info("total accuracy:{}".format(total_accuracy))

        num_of_class = len(test_data_provider.intent_lookup)
        recall = np.zeros([num_of_class])
        precision = np.zeros([num_of_class])
        accuracy = np.zeros([num_of_class])
        count = np.zeros([num_of_class])

        for cls in range(0, num_of_class):
            tn = 0
            tp = 0
            fn = 0
            fp = 0
            cnt = 0
            for res in result:
                pred = res[0]
                cond = res[1]
                pred = 1 if pred == cls else 0
                cond = 1 if cond == cls else 0
                if pred == cond == 1:
                    tp += 1
                elif pred == cond == 0:
                    tn += 1
                else:
                    if pred == 1 and cond == 0:
                        fp += 1
                    else:
                        fn += 1
                cnt += cond
            count[cls] = cnt
            recall[cls] = tp / (tp + fn)
            if tp + fp == 0:
                precision[cls] = 0
            else:
                precision[cls] = tp / (tp + fp)
            accuracy[cls] = (tp + tn) / (tp + tn + fp + fn)  # No use, since tn are too large
        fscore = (2 * recall * precision) / (recall + precision)

        logger.info("Emotion: {}".format(test_data_provider.intent_lookup))
        logger.info("recall:{}".format(recall))
        logger.info("precision:{}".format(precision))
        logger.info("F-score:{}".format(fscore))
        logger.info("mean recall:{}".format(np.mean(recall)))
        logger.info("mean precision:{}".format(np.mean(precision)))
        logger.info("mean F-score:{}".format(np.mean(fscore)))

        w = []
        d = test_data_provider.intent_lookup
        for cls in range(0, num_of_class):
            w.append((d[cls], count[cls], fscore[cls], recall[cls], precision[cls]))
        w.sort()
        return w

    def predict(self, text, *args, **kwargs):
        topk = kwargs.get("top", 1)
        return self.predictk(text, k=topk, *args, **kwargs)

        # vec = self.data_provider.data_embedding(text)
        #
        # if self.char_level:
        #     vec_ = torch.LongTensor(vec)
        # else:
        #     vec_ = torch.tensor(vec).float()
        # vec_ = torch.unsqueeze(vec_, 0)
        # X = Variable(vec_)
        # output = self.nn_model(X)
        # score, pred = torch.max(output, dim=1)
        # pred_intent = self.data_provider.get_intent(pred)
        # pred_scores = score.detach().numpy()
        # # logging.info("text:{} >> predict intent is {}, score is {}".format(text, pred_intent, score))
        # return pred_intent, pred_scores[0]

    def predictk(self, text, k=3, *args, **kwargs):

        # Check: topk 要比分類數量少
        if self.nn_params["class-number"] < k:
            logging.error("The maximum predicable number is {}".format(self.nn_params["class-number"]))
            k = self.nn_params["class-number"]

        vec = self.data_provider.data_embedding(text)

        if self.char_level:
            vec_ = torch.LongTensor(vec)
        else:
            vec_ = torch.tensor(vec).float()
        vec_ = torch.unsqueeze(vec_, 0)
        X = Variable(vec_)
        output = self.nn_model(X)
        scores, preds = torch.topk(output, k=k, dim=1)
        pred_scores = scores[0].detach().numpy()
        pred_intent = []
        for i in range(len(preds[0])):
            pred_intent.append(self.data_provider.get_intent(preds[0][i]))

        # logging.info("text:{} >> predict intent is {}".format(text, pred_intent))
        # logging.info("text:{} >> predict scores is {}".format(text, scores))
        return pred_intent, pred_scores
