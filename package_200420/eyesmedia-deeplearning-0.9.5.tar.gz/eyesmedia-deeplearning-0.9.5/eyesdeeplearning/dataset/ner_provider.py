# -*- coding: utf-8 -*-
import logging
import copy
import pickle as cPickle
import torch
from eyesdeeplearning.dataset.generic import TorchDatasetProvider

logger = logging.getLogger("eyesdeeplearning")


class NERDatasetProvider(TorchDatasetProvider):
    def __init__(self, batch_size=32):
        self.batch_size = batch_size
        self.index = 0
        self.input_size = 0
        self.data = [] #training data set
        self.batch_data = []
        self.vocab = {"unk": 0}
        self.tag_map = {"O": 0, "START": 1, "STOP": 2}
        self.tag_labels = []

        # if data_type == "train":
        #     assert tags, Exception("請指定欲訓練的標籤類型，如[\"ORG\", \"PER\"]")
        #     self.generate_tags(tags)
        #     self.data_path = "datasets/train_set"
        # elif data_type == "valid":
        #     self.data_path = "datasets/valid_set"
        #     self.load_data_map()
        # elif data_type == "test":
        #     self.data_path = "datasets/test_set"
        #     self.load_data_map()

        # self.load_data()
        # self.prepare_batch()

    def _save_dataset(self):
        return {
            "batch_size": self.batch_size,
            "batch_data": self.batch_data,
            "input_size": self.input_size,
            "vocab": self.vocab,
            "tag_map": self.tag_map,
            "tag_labels": self.tag_labels
        }

    def _load_dataset(self, dataset):
        self.batch_size = dataset["batch_size"]
        self.batch_data = dataset["batch_data"]
        self.input_size = dataset["input_size"]
        self.vocab = dataset["vocab"]
        self.tag_map = dataset["tag_map"]
        self.tag_labels = dataset["tag_labels"]

    def _get_train_data(self):
        return self.data

    def train(self, train_datas):
        """

        :param train_datas: {
                            "tags":[tag1, tag2],
                            "data": [
                                [['心經是誰翻譯的？'], ['O', 'O', 'O', 'O', 'B-misc', 'E-misc', 'O', 'O']],
                                [['心經是誰翻譯的？'], ['O', 'O', 'O', 'O', 'B-misc', 'E-misc', 'O', 'O']]...
                             ]
                             }
        """
        tag_labels = train_datas.get("tags", [])
        dataset = train_datas.get("data", [])
        self.__generate_tags(tag_labels)
        self.__load_data(dataset)
        self.__prepare_batch()

    def __generate_tags(self, tags):  # generate tags from XXX to BIOE format for tag_map
        self.tags = []
        for tag in tags:
            for prefix in ["B-", "I-", "E-"]:
                self.tags.append(prefix + tag)
        self.tags.append("O")
        self.tag_labels = tags

    def __load_data(self, dataset):
        """
        load data, add vocab and convert to one-hot encoding.
        result of data: ([sentence encoding, tag encoding])
        [[16, 19, 19, 249, 250, 145, 93, 6, 4, 5],
        [0, 0, 0, 17, 25, 18, 12, 0, 3, 4]]
        """
        for data in dataset:
            # data format: [['心經是誰翻譯的？'], ['O', 'O', 'O', 'O', 'B-misc', 'E-misc', 'O', 'O']]
            text = data[0][0]
            tags = data[1]
            sentence = []
            target = []
            for char, tag in zip(text, tags):
                if char not in self.vocab:
                    self.vocab[char] = max(self.vocab.values()) + 1
                if tag not in self.tag_map and tag in self.tags:
                    self.tag_map[tag] = len(self.tag_map.keys())
                sentence.append(self.vocab.get(char, 0))
                target.append(self.tag_map.get(tag, 0))
            self.data.append([sentence, target])
        self.input_size = len(self.vocab.values())
        # print("{} data: {}".format(self.data_type ,len(self.data)))
        # print("vocab size: {}".format(self.input_size))
        # print("unique tag: {}".format(len(self.tag_map.values())))
        # print("-"*50)

    # def convert_tag(self, data):
    #     # add E-XXX for tags
    #     # add O-XXX for tags
    #     _, tags = data
    #     converted_tags = []
    #     for _, tag in enumerate(tags[:-1]):
    #         if tag not in self.tag_map and self.data_type == "train":
    #             self.tag_map[tag] = len(self.tag_map.keys())
    #         converted_tags.append(self.tag_map.get(tag, 0))
    #     converted_tags.append(0)
    #     data[1] = converted_tags
    #     assert len(converted_tags) == len(tags), "convert error, the list dosen't match!"
    #     return data

    def __prepare_batch(self):
        '''
            prepare padded data for batch
        '''
        index = 0
        while True:
            if index + self.batch_size >= len(self.data):
                pad_data = self.__pad_data(self.data[-self.batch_size:])
                self.batch_data.append(pad_data)
                break
            else:
                pad_data = self.__pad_data(self.data[index:index + self.batch_size])
                index += self.batch_size
                self.batch_data.append(pad_data)

    def __pad_data(self, data):
        c_data = copy.deepcopy(data)
        max_length = max([len(i[0]) for i in c_data])
        for i in c_data:
            i.append(len(i[0]))
            i[0] = i[0] + (max_length - len(i[0])) * [0]
            i[1] = i[1] + (max_length - len(i[1])) * [0]
            # i[0] = torch.tensor(i[0])
            # i[1] = torch.tensor(i[1])
        return c_data

    def iteration(self):
        idx = 0
        while True:
            yield self.batch_data[idx]
            idx += 1
            if idx > len(self.batch_data) - 1:
                idx = 0

    def get_batch(self):
        """
        format:
            [
            [1, 2, 1, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0], # padded one-hot sentence
            [0, 0, 0, 0, 3, 4, 0, 5, 6, 0, 0, 0, 0, 0], # padded one-hot label
            10                                          # real length of unpadded original sentence
            ]
        """
        for data in self.batch_data:
            yield data
