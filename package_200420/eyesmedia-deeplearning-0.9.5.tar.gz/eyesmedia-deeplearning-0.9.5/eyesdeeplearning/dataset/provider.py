# -*- coding: utf-8 -*-
import logging
import numpy as np

from eyesdeeplearning.dataset.generic import TorchDatasetProvider
from eyesdeeplearning.dataset.generic import GenericTorchDataset
from eyesdeeplearning.dataset.generic import GenericChatLevelTorchDataset
from eyesdeeplearning.dict import load_base_vocab

logger = logging.getLogger("eyesdeeplearning")


class SentenceDatasetProvider(TorchDatasetProvider):

    def __init__(self, tokenizer, word_embedding, char_level=False, doc_dim=30, unigram_dim=20, bigram_dim=40):
        self.tokenizer = tokenizer
        self.word_embedding = word_embedding
        self.word_dim = word_embedding.model_dimension
        self.char_level = char_level
        if char_level:
            self.char_dict = load_base_vocab()
            self.char_dim = len(self.char_dict)
            if self.char_dim == 0:
                self.char_level = False

        self.doc_dim = doc_dim
        self.unigram_dim = unigram_dim
        self.bigram_dim = bigram_dim
        # Use WB or one-hot

    def _save_dataset(self):
        return {
            "intent_lookup": self.intent_lookup,
            "intent_dict": self.intent_dict,
            "features": self.features,
            "target": self.target,
            "doc_dim": self.doc_dim,
            "unigram_dim": self.unigram_dim,
            "bigram_dim": self.bigram_dim
        }

    def _load_dataset(self, dataset):
        self.intent_lookup = dataset["intent_lookup"]
        self.intent_dict = dataset["intent_dict"]
        self.features = dataset["features"]
        self.target = dataset["target"]
        self.doc_dim = dataset.get("doc_dim", 30)
        self.unigram_dim = dataset.get("unigram_dim", 20)
        self.bigram_dim = dataset.get("bigram_dim", 40)

    def train(self, train_datas):
        logger.info("start training data embedding....")
        sent_list = []
        intent_list = []
        for mes in train_datas:
            sent_list.append(mes["text"])
            intent_list.append(mes["intent"])

        intent_lookup = list(set(intent_list))
        intent_dict = {}
        for idx, intent in enumerate(intent_lookup):
            intent_dict[intent] = idx
        intent_id_list = []
        for intent in intent_list:
            intent_id_list.append(intent_dict[intent])

        self.intent_lookup = intent_lookup
        self.intent_dict = intent_dict

        # using tokenization
        all_mat = []
        for sent in sent_list:
            zh_sent = self.tokenizer.cn2zh(sent)
            sent_vec = self.data_embedding(zh_sent)
            all_mat.append(sent_vec)

        # logging.info("shuffling data")
        # tmp = list(zip(all_mat, intent_id_list))
        # random.shuffle(tmp)
        # self.features, self.target = zip(*tmp)
        self.features = all_mat
        self.target = intent_id_list
        logger.info("training data embedding finish....")

    def get_intent(self, intent_index):
        return self.intent_lookup[intent_index]

    def _get_train_data(self):
        idx_from = 0
        idx_to = len(self.features)
        return self.features[idx_from:idx_to], self.target[idx_from:idx_to]

    def get_generic_dataset(self):
        features, target = self._get_train_data()
        if self.char_level:
            return GenericChatLevelTorchDataset(features, target)
        return GenericTorchDataset(features, target)

    def data_embedding(self, sent):
        vec = []
        if not self.char_level:
            # 使用一般分詞 + 詞嵌入
            tokens = [term["word"] for term in self.tokenizer.standard_tokenizer(sent)]
            # 分詞之後，做Word Embedding
            for token in tokens:
                if self.word_embedding.word_exist(token):
                    vec.append(self.word_embedding.word2vec(token))
            # padding: 補上零的字向量讓矩陣長度固定
            vec_length = len(vec)
            for i in range(vec_length, self.doc_dim):
                vec.append(np.zeros([self.word_dim]))
        else:
            # 使用character-level
            tokens = list(sent)
            # 對每個字元分別給於one-hot的向量，所以長度會很大
            for token in tokens:
                vec.append(self.char_dict[token])
            # padding: 補上零的字向量讓矩陣長度固定
            vec_length = len(vec)
            for i in range(vec_length, self.doc_dim):
                vec.append(0)

        # clipping: 原本就超過最大長度的話就切掉
        vec = vec[:self.doc_dim]
        return vec
