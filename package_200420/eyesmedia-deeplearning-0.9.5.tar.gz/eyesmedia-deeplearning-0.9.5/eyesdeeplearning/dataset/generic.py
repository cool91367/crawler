# -*- coding: utf-8 -*-
import logging
import abc
import pickle
import time
import torch
import torch.utils.data as data

logger = logging.getLogger("eyesdeeplearning")


class GenericTorchDataset(data.Dataset):

    def __init__(self, feature, target):
        self.data = torch.tensor(feature).float()
        self.target = torch.tensor(target)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index], self.target[index]


class GenericChatLevelTorchDataset(GenericTorchDataset):
    def __init__(self, feature, target):
        super().__init__(feature, target)
        self.data = torch.LongTensor(feature)


class TorchDatasetProvider(abc.ABC):

    @abc.abstractmethod
    def _save_dataset(self):
        return None

    def _save_plot_dataset(self):
        return None

    @abc.abstractmethod
    def _load_dataset(self, dataset):
        pass

    @abc.abstractmethod
    def train(self, train_datas):
        pass

    def save(self, fname, for_plot=False):
        sstime = time.time()
        dataset = self._save_plot_dataset() if for_plot else self._save_dataset()
        with open(fname, 'wb') as fp:
            pickle.dump(dataset, fp, protocol=4)
        logger.info("save dataset({}) is finished, cost time is {}/s".format(fname, time.time() - sstime))

    def load(self, fname):
        sstime = time.time()
        with open(fname, 'rb') as fp:
            dataset = pickle.load(fp)
        self._load_dataset(dataset)
        logger.info("load dataset({}) is finished, cost time is {}/s".format(fname, time.time() - sstime))
