# -*- coding: utf-8 -*-
import logging
import numpy as np

logger = logging.getLogger("eyesdeeplearning")


class WordEmbedding:

    def __init__(self, w2v_model):
        # Version 1: wiki
        # wiki = {}
        # with open('/Users/admin/PycharmProjects/wiki.zh.vec') as vecs:
        #     for vec in vecs:
        #         token = vec.split()
        #         wiki[token[0]] = list(map(float, token[1:]))
        # self.wiki = wiki

        # Version 2: ptt
        # model = word2vec.Word2Vec.load("/Users/admin/PycharmProjects/TextCNN/word2vec.model")
        self.model = w2v_model
        self.model_dimension = w2v_model.vector_size

        # Version 3: one-hot and train

    def word2vec(self, word):
        # We Assume the word exist
        return self.model[word]

    def word_exist(self, word):
        if word in self.model:
            return True
        else:
            return False

    def similar_word(self, word):
        return self.model.wv.similar_by_word(word)[:5]

    def load_pretrain_embedding(self):
        embedd_dict = dict()  # word: array([[vectors]])
        # vocabs = [word for word in self.model.wv.vocab]
        vocabs = set(self.model.wv.index2word)
        # tokens = []
        for vocab in vocabs:
            if ' ' in vocab:
                # print('Bug in vocab:{}'.format(vocab))
                continue
            vector = self.model.wv.word_vec(vocab)
            # tokens.append([vocab, vector.tolist()])
            vector = list(map(str, vector.tolist()))
            tokens = [vocab] + vector  # list of [word, v1, v2, v3...]
            embedd = np.empty([1, self.model_dimension])
            embedd[:] = tokens[1:]
            embedd_dict[tokens[0]] = embedd
        return embedd_dict
